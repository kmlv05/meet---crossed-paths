const { initializeApp, cert } = require("firebase-admin/app");
const { getStorage } = require("firebase-admin/storage");
const fs = require("fs");
const path = require("path");

// Initialize Firebase Admin with the existing service account credentials
const serviceAccountPath = path.resolve("./backend/src/main/resources/serviceAccountKey.json");

if (!fs.existsSync(serviceAccountPath)) {
  console.error("Service account key not found at:", serviceAccountPath);
  process.exit(1);
}

const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, "utf-8"));

initializeApp({
  credential: cert(serviceAccount),
  storageBucket: "meet-01-fe9e8.firebasestorage.app"
});

const corsConfig = [
  {
    origin: ["*"],
    method: ["GET", "HEAD", "PUT", "POST", "DELETE"],
    responseHeader: ["Content-Type", "Authorization", "Content-Length", "User-Agent", "x-goog-resumable"],
    maxAgeSeconds: 3600
  }
];

async function configureCors() {
  try {
    const bucket = getStorage().bucket();
    await bucket.setCorsConfiguration(corsConfig);
    console.log("Successfully updated CORS configuration for Firebase Storage bucket: meet-01-fe9e8.firebasestorage.app");
  } catch (error) {
    console.error("Failed to update CORS configuration:", error);
  }
}

configureCors();

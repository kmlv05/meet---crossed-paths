package com.meet.backend.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CallSignal {
    private String type; // "offer", "answer", "candidate", "reject", "hangup"
    private String senderId;
    private String receiverId;
    private Object data; // SDP or ICE Candidate
}

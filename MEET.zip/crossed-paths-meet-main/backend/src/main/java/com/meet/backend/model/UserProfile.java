package com.meet.backend.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserProfile {
    private String id;
    private String email;
    private String name;
    private Integer age;
    private String gender;
    private String bio;
    private List<String> interests;
    private List<String> imageUrls;
    private Double latitude;
    private Double longitude;
    private Boolean isPremium = false;
}

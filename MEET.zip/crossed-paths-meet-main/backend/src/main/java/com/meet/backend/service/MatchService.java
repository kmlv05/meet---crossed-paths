package com.meet.backend.service;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import com.meet.backend.model.Match;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

@Service
public class MatchService {

    private static final String COLLECTION_LIKES = "likes";
    private static final String COLLECTION_MATCHES = "matches";

    // Like a user
    public boolean likeUser(String fromUserId, String toUserId) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        
        // Save the like
        Map<String, Object> likeData = new HashMap<>();
        likeData.put("fromUserId", fromUserId);
        likeData.put("toUserId", toUserId);
        likeData.put("timestamp", Instant.now().toEpochMilli());
        
        String likeId = fromUserId + "_" + toUserId;
        dbFirestore.collection(COLLECTION_LIKES).document(likeId).set(likeData).get();

        // Check if mutual like exists
        String reverseLikeId = toUserId + "_" + fromUserId;
        DocumentSnapshot reverseLike = dbFirestore.collection(COLLECTION_LIKES).document(reverseLikeId).get().get();

        if (reverseLike.exists()) {
            // It's a match!
            createMatch(fromUserId, toUserId, dbFirestore);
            return true; // true implies a match was created
        }
        return false;
    }

    // Dislike a user (similar structure, maybe store to avoid showing them again)
    public void dislikeUser(String fromUserId, String toUserId) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        Map<String, Object> dislikeData = new HashMap<>();
        dislikeData.put("fromUserId", fromUserId);
        dislikeData.put("toUserId", toUserId);
        dislikeData.put("timestamp", Instant.now().toEpochMilli());
        
        String dislikeId = fromUserId + "_" + toUserId;
        dbFirestore.collection("dislikes").document(dislikeId).set(dislikeData).get();
    }

    private void createMatch(String user1, String user2, Firestore dbFirestore) throws ExecutionException, InterruptedException {
        // order alphabetically to avoid duplicates (user1_user2 vs user2_user1)
        String first = user1.compareTo(user2) < 0 ? user1 : user2;
        String second = user1.compareTo(user2) < 0 ? user2 : user1;
        
        String matchId = first + "_" + second;
        
        Match match = new Match();
        match.setId(matchId);
        match.setUser1Id(first);
        match.setUser2Id(second);
        match.setTimestamp(Instant.now().toEpochMilli());
        
        dbFirestore.collection(COLLECTION_MATCHES).document(matchId).set(match).get();
    }

    public List<Match> getMatches(String userId) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        
        // Firestore doesn't support logical OR queries simply across multiple fields in older SDKs.
        // We do two queries and merge for user1Id == userId OR user2Id == userId
        ApiFuture<QuerySnapshot> query1 = dbFirestore.collection(COLLECTION_MATCHES).whereEqualTo("user1Id", userId).get();
        ApiFuture<QuerySnapshot> query2 = dbFirestore.collection(COLLECTION_MATCHES).whereEqualTo("user2Id", userId).get();
        
        List<QueryDocumentSnapshot> matches1 = query1.get().getDocuments();
        List<QueryDocumentSnapshot> matches2 = query2.get().getDocuments();
        
        List<Match> result = new ArrayList<>();
        matches1.forEach((doc) -> result.add(doc.toObject(Match.class)));
        matches2.forEach((doc) -> result.add(doc.toObject(Match.class)));
        
        return result;
    }
}

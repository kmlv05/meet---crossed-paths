package com.meet.backend.controller;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import com.meet.backend.model.ChatMessage;
import com.meet.backend.model.CallSignal;
import com.meet.backend.service.ChatService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import java.util.Map;

@Controller
public class ChatWebSocketController {
    
    private static final Logger logger = LoggerFactory.getLogger(ChatWebSocketController.class);
    
    private final SimpMessagingTemplate messagingTemplate;
    private final ChatService chatService;

    public ChatWebSocketController(SimpMessagingTemplate messagingTemplate, ChatService chatService) {
        this.messagingTemplate = messagingTemplate;
        this.chatService = chatService;
    }

    @MessageMapping("/chat.send")
    public void processMessage(@Payload ChatMessage chatMessage, StompHeaderAccessor accessor) {
        try {
            // Verify Firebase Auth Token sent via native STOMP headers
            String token = accessor.getFirstNativeHeader("Authorization");
            if (token != null && token.startsWith("Bearer ")) {
                token = token.substring(7);
                FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(token);
                if (!decodedToken.getUid().equals(chatMessage.getSenderId())) {
                     logger.warn("Unauthorized attempt to spoof senderId: " + chatMessage.getSenderId());
                     return;
                }
            } else {
                logger.warn("No token provided to WebSocket Endpoint");
                return;
            }

            // Process and save securely to Firestore
            ChatMessage saved = chatService.sendMessage(chatMessage);
            
            // Broadcast the saved message with precise timestamp back to both clients instantly
            messagingTemplate.convertAndSend("/topic/messages/" + chatMessage.getReceiverId(), saved);
            messagingTemplate.convertAndSend("/topic/messages/" + chatMessage.getSenderId(), saved);
            
        } catch (Exception e) {
            logger.error("Failed to process STOMP websocket message", e);
        }
    }

    @MessageMapping("/chat.read")
    public void processReadReceipt(@Payload Map<String, String> payload, StompHeaderAccessor accessor) {
        try {
            String token = accessor.getFirstNativeHeader("Authorization");
            if (token != null && token.startsWith("Bearer ")) {
                token = token.substring(7);
                FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(token);
                
                String readerId = payload.get("readerId");
                String senderId = payload.get("senderId");
                
                if (!decodedToken.getUid().equals(readerId)) {
                     logger.warn("Unauthorized read receipt trigger");
                     return;
                }
                
                chatService.markMessagesAsRead(senderId, readerId);
                
                messagingTemplate.convertAndSend("/topic/messages.read/" + senderId, 
                    Map.of("readerId", readerId, "isRead", true));
            }
        } catch (Exception e) {
            logger.error("Failed to process read receipt", e);
        }
    }

    @MessageMapping("/call.signal")
    public void processCallSignal(@Payload CallSignal signal, StompHeaderAccessor accessor) {
        try {
            // Verify Auth
            String token = accessor.getFirstNativeHeader("Authorization");
            if (token != null && token.startsWith("Bearer ")) {
                token = token.substring(7);
                FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(token);
                if (!decodedToken.getUid().equals(signal.getSenderId())) {
                     return;
                }
            } else {
                return;
            }

            // Route signal to the receiver
            messagingTemplate.convertAndSend("/topic/calls/" + signal.getReceiverId(), signal);
            
        } catch (Exception e) {
            logger.error("Failed to route call signal", e);
        }
    }
}

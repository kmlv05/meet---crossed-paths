package com.meet.backend.service;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import com.meet.backend.model.ChatMessage;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

@Service
public class ChatService {

    private static final String COLLECTION_CHATS = "chats";

    public ChatMessage sendMessage(ChatMessage inputMessage) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        
        if (inputMessage.getId() == null || inputMessage.getId().isEmpty()) {
            inputMessage.setId(UUID.randomUUID().toString());
        }
        if (inputMessage.getTimestamp() == null) {
            inputMessage.setTimestamp(Instant.now().toEpochMilli());
        }
        
        dbFirestore.collection(COLLECTION_CHATS).document(inputMessage.getId()).set(inputMessage).get();
        return inputMessage;
    }

    public void markMessagesAsRead(String senderId, String readerId) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        ApiFuture<QuerySnapshot> query = dbFirestore.collection(COLLECTION_CHATS)
                .whereEqualTo("senderId", senderId)
                .whereEqualTo("receiverId", readerId)
                .whereEqualTo("isRead", false)
                .get();

        List<QueryDocumentSnapshot> docs = query.get().getDocuments();
        if (docs.isEmpty()) return;

        WriteBatch batch = dbFirestore.batch();
        for (QueryDocumentSnapshot doc : docs) {
            batch.update(doc.getReference(), "isRead", true);
        }
        batch.commit();
    }

    public List<ChatMessage> getChatHistory(String userId, String otherUserId) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        
        ApiFuture<QuerySnapshot> query1 = dbFirestore.collection(COLLECTION_CHATS)
                .whereEqualTo("senderId", userId)
                .whereEqualTo("receiverId", otherUserId)
                .get();
                
        ApiFuture<QuerySnapshot> query2 = dbFirestore.collection(COLLECTION_CHATS)
                .whereEqualTo("senderId", otherUserId)
                .whereEqualTo("receiverId", userId)
                .get();

        List<QueryDocumentSnapshot> docs1 = query1.get().getDocuments();
        List<QueryDocumentSnapshot> docs2 = query2.get().getDocuments();
        
        List<ChatMessage> history = new ArrayList<>();
        docs1.forEach((doc) -> history.add(doc.toObject(ChatMessage.class)));
        docs2.forEach((doc) -> history.add(doc.toObject(ChatMessage.class)));
        
        // Sort by timestamp
        history.sort((m1, m2) -> m1.getTimestamp().compareTo(m2.getTimestamp()));
        
        return history;
    }
}

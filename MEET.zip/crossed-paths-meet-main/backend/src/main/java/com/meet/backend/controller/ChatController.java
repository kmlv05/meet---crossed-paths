package com.meet.backend.controller;

import com.meet.backend.model.ChatMessage;
import com.meet.backend.service.ChatService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @PostMapping("/send/{receiverId}")
    public ResponseEntity<ChatMessage> sendMessage(
            @PathVariable String receiverId,
            @RequestBody ChatMessage body) throws ExecutionException, InterruptedException {
        String uid = getUserId();
        body.setSenderId(uid);
        body.setReceiverId(receiverId);
        ChatMessage message = chatService.sendMessage(body);
        return ResponseEntity.ok(message);
    }

    @GetMapping("/history/{otherUserId}")
    public ResponseEntity<List<ChatMessage>> getHistory(@PathVariable String otherUserId) throws ExecutionException, InterruptedException {
        String uid = getUserId();
        List<ChatMessage> history = chatService.getChatHistory(uid, otherUserId);
        return ResponseEntity.ok(history);
    }

    private String getUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getName();
    }
}

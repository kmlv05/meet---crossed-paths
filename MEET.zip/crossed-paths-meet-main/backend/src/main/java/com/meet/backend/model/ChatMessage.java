package com.meet.backend.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatMessage {
    private String id;
    private String senderId;
    private String receiverId;
    private String message;
    private String messageType; // e.g., "text", "image", "audio", "video"
    private String mediaUrl;
    private Long timestamp;
    private Boolean isRead = false;
}

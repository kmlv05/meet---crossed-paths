package com.meet.backend.controller;

import com.meet.backend.model.UserProfile;
import com.meet.backend.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/profile")
    public ResponseEntity<UserProfile> getProfile() throws ExecutionException, InterruptedException {
        String uid = getUserId();
        UserProfile profile = userService.getUserProfile(uid);
        if (profile == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(profile);
    }

    @GetMapping("/profile/{userId}")
    public ResponseEntity<UserProfile> getUserProfile(@PathVariable String userId) throws ExecutionException, InterruptedException {
        UserProfile profile = userService.getUserProfile(userId);
        if (profile == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(profile);
    }

    @PostMapping("/profile")
    public ResponseEntity<UserProfile> createOrUpdateProfile(@RequestBody UserProfile profile) throws ExecutionException, InterruptedException {
        String uid = getUserId();
        profile.setId(uid); // Ensure user can only update their own profile
        UserProfile savedProfile = userService.saveUserProfile(profile);
        return ResponseEntity.ok(savedProfile);
    }

    @PutMapping("/location")
    public ResponseEntity<Void> updateLocation(@RequestParam double lat, @RequestParam double lng) throws ExecutionException, InterruptedException {
        String uid = getUserId();
        userService.updateLocation(uid, lat, lng);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/nearby")
    public ResponseEntity<List<UserProfile>> getNearbyUsers(
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(defaultValue = "50.0") Double radius,
            @RequestParam(required = false) String lastUserId) throws ExecutionException, InterruptedException {
        String uid = getUserId();
        List<UserProfile> users = userService.getNearbyUsers(uid, lat, lng, radius, lastUserId);
        return ResponseEntity.ok(users);
    }

    @PostMapping("/report/{userId}")
    public ResponseEntity<Void> reportUser(@PathVariable String userId, @RequestBody(required = false) String reason) {
        // In a real production app, this saves to a Firestore 'reports' collection
        System.out.println("SAFETY: User " + getUserId() + " reported " + userId + " for: " + reason);
        return ResponseEntity.ok().build();
    }

    private String getUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getName();
    }
}

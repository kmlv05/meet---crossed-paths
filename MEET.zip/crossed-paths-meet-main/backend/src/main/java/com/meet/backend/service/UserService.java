package com.meet.backend.service;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import com.meet.backend.model.UserProfile;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

@Service
public class UserService {

    private static final String COLLECTION_NAME = "users";

    public UserProfile saveUserProfile(UserProfile userProfile) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection(COLLECTION_NAME).document(userProfile.getId());
        ApiFuture<WriteResult> collectionsApiFuture = documentReference.set(userProfile);
        collectionsApiFuture.get(); // Wait for actual write
        return userProfile;
    }

    public void updateLocation(String uid, double lat, double lng) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection(COLLECTION_NAME).document(uid);
        documentReference.update("latitude", lat, "longitude", lng).get();
    }

    public void updatePremiumStatus(String uid, boolean isPremium) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection(COLLECTION_NAME).document(uid);
        documentReference.update("isPremium", isPremium).get();
    }

    public UserProfile getUserProfile(String uid) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection(COLLECTION_NAME).document(uid);
        ApiFuture<DocumentSnapshot> future = documentReference.get();
        DocumentSnapshot document = future.get();
        
        if (document.exists()) {
            return document.toObject(UserProfile.class);
        } else {
            return null;
        }
    }

    public List<UserProfile> getNearbyUsers(String currentUserId, Double lat, Double lng, double radiusInKm, String lastUserId) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        
        // 1. Production Pagination: Limit results to chunks of 50 to prevent out-of-memory errors
        // on the server and minimize cost on Firestore read limits as the app grows.
        Query query = dbFirestore.collection(COLLECTION_NAME).limit(50);
        
        if (lastUserId != null && !lastUserId.isEmpty()) {
            DocumentSnapshot lastDoc = dbFirestore.collection(COLLECTION_NAME).document(lastUserId).get().get();
            if (lastDoc.exists()) {
                query = query.startAfter(lastDoc);
            }
        }
        
        ApiFuture<QuerySnapshot> future = query.get();
        List<QueryDocumentSnapshot> documents = future.get().getDocuments();
        
        List<UserProfile> nearbyUsers = new ArrayList<>();
        
        for (QueryDocumentSnapshot document : documents) {
            UserProfile user = document.toObject(UserProfile.class);
            if (user.getId().equals(currentUserId)) {
                continue; // Skip current user
            }
            if (user.getLatitude() != null && user.getLongitude() != null && lat != null && lng != null) {
                double distance = calculateDistanceInKilometer(lat, lng, user.getLatitude(), user.getLongitude());
                if (distance <= radiusInKm) {
                    nearbyUsers.add(user);
                }
            } else {
                // Return users without location just as candidates if mock/no location is required
                nearbyUsers.add(user);
            }
        }
        return nearbyUsers;
    }

    private double calculateDistanceInKilometer(double userLat, double userLng, double venueLat, double venueLng) {
        double latDistance = Math.toRadians(userLat - venueLat);
        double lngDistance = Math.toRadians(userLng - venueLng);

        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(userLat)) * Math.cos(Math.toRadians(venueLat))
                * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return 6371 * c; // Earth radius in kilometers
    }
}

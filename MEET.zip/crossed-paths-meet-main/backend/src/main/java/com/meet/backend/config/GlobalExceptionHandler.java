package com.meet.backend.config;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Throwable.class)
    public ResponseEntity<Map<String, String>> handleAll(Throwable t) {
        t.printStackTrace(); // Ensures it prints clearly to the Java terminal
        
        Map<String, String> error = new HashMap<>();
        String message = t.getMessage() != null ? t.getMessage() : "null";
        String cause = t.getCause() != null ? t.getCause().toString() : "none";
        
        error.put("error", "JAVA CRASH [" + t.getClass().getSimpleName() + "]: " + message + " | Cause: " + cause);
        
        return ResponseEntity.internalServerError().body(error);
    }
}

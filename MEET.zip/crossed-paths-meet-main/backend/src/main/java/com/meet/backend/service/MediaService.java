package com.meet.backend.service;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class MediaService {

    private final ModerationService moderationService;

    public MediaService(ModerationService moderationService) {
        this.moderationService = moderationService;
    }

    public String uploadMedia(MultipartFile file, String userId) throws IOException {
        // Simple filename generation based on original name or timestamp
        String originalFilename = file.getOriginalFilename();
        String extension = "bin";
        if (originalFilename != null && originalFilename.contains(".")) {
            extension = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        }

        RestTemplate restTemplate = new RestTemplate();
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
        
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("reqtype", "fileupload");
        
        final String finalExtension = extension;
        ByteArrayResource fileResource = new ByteArrayResource(file.getBytes()) {
            @Override
            public String getFilename() {
                return "upload_" + System.currentTimeMillis() + "." + finalExtension;
            }
        };
        body.add("fileToUpload", fileResource);
        
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
        
        // Send directly to the public Catbox CDN (Supports Image, Video, Audio)
        ResponseEntity<String> response = restTemplate.postForEntity("https://catbox.moe/user/api.php", requestEntity, String.class);
        
        if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null && response.getBody().startsWith("http")) {
            return response.getBody().trim();
        } else {
            throw new IOException("Failed to upload media to CDN. Response: " + response.getBody());
        }
    }
}

package com.meet.backend.controller;

import com.meet.backend.model.Match;
import com.meet.backend.service.MatchService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/match")
public class MatchController {

    private final MatchService matchService;

    public MatchController(MatchService matchService) {
        this.matchService = matchService;
    }

    @PostMapping("/like/{toUserId}")
    public ResponseEntity<Map<String, Object>> likeUser(@PathVariable String toUserId) throws ExecutionException, InterruptedException {
        String uid = getUserId();
        boolean isMatch = matchService.likeUser(uid, toUserId);
        
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("isMatch", isMatch);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/dislike/{toUserId}")
    public ResponseEntity<Map<String, Object>> dislikeUser(@PathVariable String toUserId) throws ExecutionException, InterruptedException {
        String uid = getUserId();
        matchService.dislikeUser(uid, toUserId);
        
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/list")
    public ResponseEntity<List<Match>> getMatches() throws ExecutionException, InterruptedException {
        String uid = getUserId();
        List<Match> matches = matchService.getMatches(uid);
        return ResponseEntity.ok(matches);
    }

    private String getUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getName();
    }
}

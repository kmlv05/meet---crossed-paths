package com.meet.backend.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Match {
    private String id;
    private String user1Id;
    private String user2Id;
    private Long timestamp;
}

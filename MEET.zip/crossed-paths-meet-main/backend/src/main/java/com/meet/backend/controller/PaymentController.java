package com.meet.backend.controller;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;
import com.meet.backend.service.UserService;
import com.stripe.Stripe;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.exception.StripeException;
import com.stripe.model.Event;
import com.stripe.model.EventDataObjectDeserializer;
import com.stripe.model.checkout.Session;
import com.stripe.net.Webhook;
import com.stripe.param.checkout.SessionCreateParams;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Value("${stripe.api.key}")
    private String stripeApiKey;

    @Value("${stripe.webhook.secret}")
    private String endpointSecret;

    @Autowired
    private UserService userService;

    @PostConstruct
    public void init() {
        Stripe.apiKey = stripeApiKey;
    }

    @PostMapping("/create-checkout-session")
    public ResponseEntity<?> createCheckoutSession(@RequestHeader("Authorization") String token, @RequestBody Map<String, String> request) {
        try {
            String jwt = token.substring(7);
            FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(jwt);
            String uid = decodedToken.getUid();
            String email = decodedToken.getEmail();

            String planType = request.getOrDefault("planType", "monthly"); // "weekly" or "monthly"
            String origin = request.getOrDefault("origin", "http://localhost:5173");
            
            long amount = 19900L; // ₹199.00
            String productName = "Meet Premium Monthly";
            if ("weekly".equalsIgnoreCase(planType)) {
                amount = 5000L; // ₹50.00
                productName = "Meet Premium Weekly";
            }

            SessionCreateParams.Builder paramsBuilder = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl(origin + "/payment/success")
                .setCancelUrl(origin + "/payment/cancel")
                .putMetadata("userId", uid)
                .putMetadata("planType", planType)
                .addLineItem(
                    SessionCreateParams.LineItem.builder()
                        .setQuantity(1L)
                        .setPriceData(
                            SessionCreateParams.LineItem.PriceData.builder()
                                .setCurrency("inr")
                                .setUnitAmount(amount)
                                .setProductData(
                                    SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                        .setName(productName)
                                        .build())
                                .build())
                        .build());
                        
            if (email != null && !email.trim().isEmpty()) {
                paramsBuilder.setCustomerEmail(email);
            }

            Session session = Session.create(paramsBuilder.build());

            Map<String, String> responseData = new HashMap<>();
            responseData.put("url", session.getUrl());
            return ResponseEntity.ok(responseData);

        } catch (FirebaseAuthException | StripeException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @PostMapping("/webhook")
    public ResponseEntity<String> handleStripeWebhook(@RequestBody String payload, @RequestHeader("Stripe-Signature") String sigHeader) {
        Event event = null;

        try {
            event = Webhook.constructEvent(payload, sigHeader, endpointSecret);
        } catch (SignatureVerificationException e) {
            System.out.println("Invalid signature");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        if ("checkout.session.completed".equals(event.getType())) {
            EventDataObjectDeserializer dataObjectDeserializer = event.getDataObjectDeserializer();
            if (dataObjectDeserializer.getObject().isPresent()) {
                Session session = (Session) dataObjectDeserializer.getObject().get();
                String userId = session.getMetadata().get("userId");
                if (userId != null) {
                    try {
                        userService.updatePremiumStatus(userId, true);
                        System.out.println("Upgraded user " + userId + " to premium via Stripe!");
                    } catch (ExecutionException | InterruptedException e) {
                        e.printStackTrace();
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                    }
                }
            }
        }

        return ResponseEntity.ok("");
    }
}

import { Button } from "@/components/ui/button";
import { XCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

const PaymentCancelScreen = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 animate-fade-in">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="flex justify-center">
          <XCircle className="h-24 w-24 text-red-500" />
        </div>
        <h1 className="text-3xl font-bold font-display">Payment Cancelled</h1>
        <p className="text-muted-foreground">
          Your payment was cancelled. Your account has not been charged and you remain on the free tier.
        </p>
        <Button 
          className="w-full h-12 rounded-xl text-lg font-semibold mt-8 bg-secondary text-secondary-foreground hover:bg-secondary/80"
          onClick={() => navigate("/")}
        >
          Back to Home
        </Button>
      </div>
    </div>
  );
};

export default PaymentCancelScreen;

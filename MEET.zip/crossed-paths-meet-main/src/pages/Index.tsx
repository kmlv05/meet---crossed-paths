import { useState, useEffect } from "react";
import SplashScreen from "@/components/SplashScreen";
import OnboardingScreen from "@/components/OnboardingScreen";
import AuthScreen from "@/components/AuthScreen";
import ProfileSetupScreen from "@/components/ProfileSetupScreen";
import HomeScreen from "@/components/HomeScreen";
import { auth } from "@/lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { Mail } from "lucide-react";

type AppState = "loading" | "splash" | "onboarding" | "auth" | "setup" | "home" | "verify";

const Index = () => {
  const [appState, setAppState] = useState<AppState>("loading");
  const [hasCheckedAuth, setHasCheckedAuth] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        // if (!user.emailVerified) {
        //   setAppState("verify");
        // } else 
        if (!hasCheckedAuth) {
          try {
            const token = await user.getIdToken();
            // Optional: fallback to env vars in production, hardcoding local for this demo logic
            const res = await fetch("http://localhost:8082/api/users/profile", {
              headers: { Authorization: `Bearer ${token}` }
            });
            if (res.ok) {
              const data = await res.json();
              if (data && data.imageUrls && data.imageUrls.length > 0) {
                setAppState("home");
              } else {
                setAppState("setup");
              }
            } else {
              setAppState("setup");
            }
          } catch(e) {
            setAppState("setup");
          }
        }
      } else {
        setAppState("splash");
      }
      setHasCheckedAuth(true);
    });

    return () => unsubscribe();
  }, [hasCheckedAuth]);

  useEffect(() => {
    if (appState === "splash") {
      const timer = setTimeout(() => setAppState("onboarding"), 2500);
      return () => clearTimeout(timer);
    }
  }, [appState]);

  switch (appState) {
    case "loading":
    case "splash":
      return <SplashScreen />;
    case "onboarding":
      return <OnboardingScreen onComplete={() => setAppState("auth")} />;
    case "auth":
      return <AuthScreen onComplete={() => window.location.reload()} />;
    case "setup":
      return <ProfileSetupScreen onComplete={() => window.location.reload()} />;
    case "home":
      return <HomeScreen />;
    case "verify":
      return (
        <div className="flex min-h-screen flex-col items-center justify-center p-6 text-center bg-background">
           <Mail className="h-12 w-12 text-primary mb-4" />
           <h2 className="text-2xl font-bold font-display text-foreground">Verify Your Email</h2>
           <p className="text-muted-foreground mt-2 mb-6">We sent a secure verification link to your email address. Please click it to verify your account, then refresh this page to continue.</p>
           <button onClick={async () => {
             const user = auth.currentUser;
             if (user) {
               await user.reload(); // Refresh metadata from Firebase server
               await user.getIdToken(true); // Force push updated email_verified claim into the JWT
               window.location.reload();
             } else {
               window.location.reload();
             }
           }} className="w-full max-w-xs py-3.5 rounded-xl gradient-royal text-accent-foreground font-bold shadow-elevated mb-4 transition-transform hover:scale-105">I've verified my email</button>
           <button onClick={() => auth.signOut()} className="text-sm font-medium text-muted-foreground hover:text-foreground">Sign Out</button>
        </div>
      );
    default:
      return <SplashScreen />;
  }
};

export default Index;

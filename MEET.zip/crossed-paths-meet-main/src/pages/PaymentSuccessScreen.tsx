import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

const PaymentSuccessScreen = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 animate-fade-in">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="flex justify-center">
          <CheckCircle2 className="h-24 w-24 text-green-500" />
        </div>
        <h1 className="text-3xl font-bold font-display">Payment Successful!</h1>
        <p className="text-muted-foreground">
          Welcome to Meet Premium. Your account has been upgraded and you now have access to all premium features.
        </p>
        <Button 
          className="w-full h-12 rounded-xl text-lg font-semibold mt-8"
          onClick={() => navigate("/")}
        >
          Start Exploring
        </Button>
      </div>
    </div>
  );
};

export default PaymentSuccessScreen;

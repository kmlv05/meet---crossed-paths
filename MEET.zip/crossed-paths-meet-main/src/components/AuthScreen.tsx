import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Heart, Mail, Phone, ArrowRight, AlertCircle } from "lucide-react";
import { auth } from "@/lib/firebase";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, sendEmailVerification } from "firebase/auth";
import { toast } from "sonner";
import { api } from "@/lib/api";

interface AuthScreenProps {
  onComplete: () => void;
}

const AuthScreen = ({ onComplete }: AuthScreenProps) => {
  const [mode, setMode] = useState<"login" | "signup">("signup");
  const [method, setMethod] = useState<"email" | "phone">("email");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [ageError, setAgeError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showGoogleDobPopup, setShowGoogleDobPopup] = useState(false);
  const [googleCredUser, setGoogleCredUser] = useState<any>(null);

  const validateAge = (): boolean => {
    if (!dob) {
      setAgeError("Please enter your date of birth");
      return false;
    }
    const birth = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    if (age < 16) {
      setAgeError("You must be at least 16 years old to use this app");
      return false;
    }
    setAgeError("");
    return true;
  };

  const syncProfileToBackend = async (uid: string) => {
    try {
      await api.post("/api/users/profile", {
        id: uid,
        email,
        name: name || "New User",
        age: dob ? new Date().getFullYear() - new Date(dob).getFullYear() : 18,
      });
    } catch (e) {
      console.warn("Could not sync profile yet, might not be setup.", e);
    }
  };

  const handleContinue = async () => {
    if (mode === "signup" && !validateAge()) return;
    if (method !== "email") {
      toast.error("Phone auth is not fully configured. Please use email for now.");
      return;
    }
    
    setLoading(true);
    try {
      if (mode === "signup") {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        await syncProfileToBackend(cred.user.uid);
        await sendEmailVerification(cred.user);
        toast.success("Account created! Please check your email to verify it.");
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        if (!auth.currentUser?.emailVerified) {
             toast.info("Please remember to verify your email address.");
        } else {
             toast.success("Logged in successfully!");
        }
      }
      onComplete();
    } catch (error: any) {
      toast.error(error.message || "Failed to authenticate");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const cred = await signInWithPopup(auth, provider);
      // Sync basic info if signing up 
      if (mode === "signup") {
        setGoogleCredUser(cred.user);
        setShowGoogleDobPopup(true);
      } else {
        toast.success("Authenticated with Google!");
        onComplete();
      }
    } catch (error: any) {
      toast.error(error.message || "Google Sign-In failed");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleDobSubmit = async () => {
    if (!validateAge()) return;
    setLoading(true);
    try {
      await api.post("/api/users/profile", {
        id: googleCredUser.uid,
        email: googleCredUser.email,
        name: googleCredUser.displayName || "Google User",
        age: new Date().getFullYear() - new Date(dob).getFullYear(),
      });
      toast.success("Authenticated with Google!");
      setShowGoogleDobPopup(false);
      onComplete();
    } catch (error: any) {
      toast.error("Failed to save profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-background px-6 py-12">
      <div className="flex flex-col items-center gap-3 mb-10 animate-fade-up">
        <Heart className="h-10 w-10 text-accent fill-accent" />
        <h1 className="font-display text-3xl font-bold text-primary">
          Meet <span className="text-accent">❤️</span>
        </h1>
      </div>

      <div className="flex-1 flex flex-col gap-5 max-w-sm mx-auto w-full animate-fade-up" style={{ animationDelay: "0.15s" }}>
        <div>
          <h2 className="font-display text-2xl font-bold text-foreground">
            {mode === "signup" ? "Create Account" : "Welcome Back"}
          </h2>
          <p className="text-muted-foreground mt-1 text-sm">
            {mode === "signup" ? "Start finding people near you" : "Sign in to continue"}
          </p>
        </div>

        <button
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="flex items-center justify-center gap-3 w-full h-14 rounded-2xl bg-card shadow-card border border-border text-foreground font-medium hover:bg-secondary transition-colors disabled:opacity-50"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" xmlns="http://www.w3.org/2000/svg">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18A10.96 10.96 0 0 0 1 12c0 1.77.42 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
          Continue with Google
        </button>

        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-border" />
          <span className="text-xs text-muted-foreground">or</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        <div className="flex rounded-xl bg-secondary p-1">
          <button
            onClick={() => setMethod("email")}
            className={`flex-1 flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-medium transition-all ${
              method === "email" ? "bg-card shadow-card text-foreground" : "text-muted-foreground"
            }`}
          >
            <Mail className="h-4 w-4" /> Email
          </button>
          <button
            onClick={() => setMethod("phone")}
            className={`flex-1 flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-medium transition-all ${
              method === "phone" ? "bg-card shadow-card text-foreground" : "text-muted-foreground"
            }`}
          >
            <Phone className="h-4 w-4" /> Phone
          </button>
        </div>

        <div className="space-y-3">
          {mode === "signup" && (
            <>
              <Input
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-13 rounded-xl bg-card border-border px-4 text-base placeholder:text-muted-foreground"
              />
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Date of Birth</label>
                <Input
                  type="date"
                  value={dob}
                  onChange={(e) => { setDob(e.target.value); setAgeError(""); }}
                  className="h-13 rounded-xl bg-card border-border px-4 text-base text-foreground"
                />
                {ageError && (
                  <div className="flex items-center gap-1.5 mt-2 text-destructive">
                    <AlertCircle className="h-3.5 w-3.5" />
                    <span className="text-xs font-medium">{ageError}</span>
                  </div>
                )}
              </div>
            </>
          )}
          {method === "email" ? (
            <div className="space-y-3">
              <Input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-13 rounded-xl bg-card border-border px-4 text-base placeholder:text-muted-foreground"
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-13 rounded-xl bg-card border-border px-4 text-base placeholder:text-muted-foreground"
              />
            </div>
          ) : (
            <Input
              type="tel"
              placeholder="Phone number"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="h-13 rounded-xl bg-card border-border px-4 text-base placeholder:text-muted-foreground"
            />
          )}
        </div>

        <Button
          onClick={handleContinue}
          disabled={loading}
          className="w-full h-14 rounded-2xl gradient-royal text-accent-foreground text-lg font-semibold border-0 shadow-elevated hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {loading ? "Processing..." : mode === "signup" ? "Continue" : "Sign In"}
          {!loading && <ArrowRight className="ml-2 h-5 w-5" />}
        </Button>

        <p className="text-center text-sm text-muted-foreground">
          {mode === "signup" ? "Already have an account?" : "Don't have an account?"}{" "}
          <button
            onClick={() => { setMode(mode === "signup" ? "login" : "signup"); setPassword(""); }}
            className="font-semibold text-primary hover:underline"
          >
            {mode === "signup" ? "Sign In" : "Sign Up"}
          </button>
        </p>
      </div>

      {showGoogleDobPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 backdrop-blur-sm px-4">
          <div className="bg-card w-full max-w-sm rounded-[24px] p-6 shadow-elevated border border-border animate-fade-up flex flex-col gap-4">
            <h3 className="font-display text-xl font-bold text-foreground">What is your date of birth?</h3>
            <p className="text-sm text-muted-foreground">We need this to calculate your age. You must be at least 16 to join.</p>
            
            <div>
              <Input
                type="date"
                value={dob}
                onChange={(e) => { setDob(e.target.value); setAgeError(""); }}
                className="h-13 rounded-xl bg-background border-border px-4 text-base text-foreground w-full appearance-none"
              />
              {ageError && (
                <div className="flex items-center gap-1.5 mt-2 text-destructive">
                  <AlertCircle className="h-3.5 w-3.5" />
                  <span className="text-xs font-medium">{ageError}</span>
                </div>
              )}
            </div>

            <Button
              onClick={handleGoogleDobSubmit}
              disabled={loading}
              className="w-full h-14 rounded-2xl bg-foreground text-background font-semibold hover:opacity-90 transition-opacity mt-2"
            >
              {loading ? "Saving..." : "Continue"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AuthScreen;

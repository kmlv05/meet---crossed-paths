import { getAvatarStyle, type MockUser } from "@/data/mockData";
import { Check, CheckCheck } from "lucide-react";

interface ChatListProps {
  matches: MockUser[];
  onOpenChat: (user: MockUser) => void;
}

const StatusIcon = ({ status }: { status?: string }) => {
  if (status === "read") return <CheckCheck className="h-3 w-3 text-blue-500 mr-1 inline-block shrink-0" />;
  if (status === "delivered") return <CheckCheck className="h-3 w-3 text-muted-foreground mr-1 inline-block shrink-0" />;
  return <Check className="h-3 w-3 text-muted-foreground mr-1 inline-block shrink-0" />;
};

const ChatList = ({ matches, onOpenChat }: ChatListProps) => {
  return (
    <div className="px-5 pt-3">
      <h3 className="text-sm font-semibold text-foreground mb-3">Matches & Chats</h3>

      {/* New matches strip */}
      <div className="mb-4">
        <p className="text-xs text-muted-foreground mb-2">New Matches</p>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
          {matches.map((user) => (
            <button
              key={user.id}
              onClick={() => onOpenChat(user)}
              className="flex flex-col items-center gap-1 flex-shrink-0"
            >
              <div className="h-14 w-14 rounded-full gradient-warm p-[2px]">
                {user.realImageUrls && user.realImageUrls.length > 0 ? (
                  <img src={user.realImageUrls[0]} alt={user.name} className="h-full w-full rounded-full object-cover border-[1px] border-background" />
                ) : (
                  <div className="h-full w-full rounded-full border-2 border-background" style={getAvatarStyle(user.img)} />
                )}
              </div>
              <span className="text-[10px] font-medium text-foreground">{user.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Chat threads */}
      <div className="space-y-1">
        {matches.map((user, i) => {
          const msg = user.lastMessage;
          return (
            <button
              key={user.id}
              onClick={() => onOpenChat(user)}
              className="flex items-center gap-3 w-full rounded-xl p-3 hover:bg-card transition-colors animate-slide-in"
              style={{ animationDelay: `${i * 0.08}s` }}
            >
              <div className="relative flex-shrink-0">
                {user.realImageUrls && user.realImageUrls.length > 0 ? (
                  <img src={user.realImageUrls[0]} alt={user.name} className="h-12 w-12 rounded-full object-cover" />
                ) : (
                  <div className="h-12 w-12 rounded-full" style={getAvatarStyle(user.img)} />
                )}
                {user.online && (
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background bg-green-500" />
                )}
              </div>
              <div className="flex-1 min-w-0 text-left">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-foreground">{user.name}</p>
                  <span className="text-[10px] text-muted-foreground">{msg?.time}</span>
                </div>
                <p className="text-xs text-muted-foreground truncate flex items-center">
                  {msg?.isMine && <StatusIcon status={msg?.status} />}
                  <span className="truncate">{msg?.text || "Say hi! 👋"}</span>
                </p>
              </div>
              {msg && msg.unread > 0 && (
                <span className="flex h-5 w-5 items-center justify-center rounded-full gradient-warm text-[10px] font-bold text-accent-foreground">
                  {msg.unread}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ChatList;

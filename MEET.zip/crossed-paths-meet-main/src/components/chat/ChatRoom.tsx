import { useState, useEffect, useRef } from "react";
import { ArrowLeft, Send, Mic, Image, Smile, Timer, Sparkles, Check, CheckCheck, Phone, Video, Shield, AlertTriangle } from "lucide-react";
import { getAvatarStyle, ICEBREAKERS, type MockUser } from "@/data/mockData";
import CallScreen from "@/components/chat/CallScreen";
import { api } from "@/lib/api";
import { auth } from "@/lib/firebase";
import { Client } from "@stomp/stompjs";
import { toast } from "sonner";

interface ChatRoomProps {
  user: any;
  onBack: () => void;
}

interface Message {
  id: string | number;
  text: string;
  sender: "me" | "them";
  time: string;
  disappearing?: boolean;
  status?: "sending" | "sent" | "delivered" | "read";
  isScreenshotAlert?: boolean;
  type?: "text" | "audio" | "image" | "video";
  mediaUrl?: string;
}

const ChatRoom = ({ user, onBack }: ChatRoomProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [disappearingMode, setDisappearingMode] = useState(false);
  const [showIcebreaker, setShowIcebreaker] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  // (Removed callType, using activeCall instead)
  
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [recordingTime, setRecordingTime] = useState(0);
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  const stompClientRef = useRef<Client | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const currentUserId = auth.currentUser?.uid;

  const [activeCall, setActiveCall] = useState<{
    type: "voice" | "video";
    isIncoming: boolean;
    incomingOffer?: any;
  } | null>(null);
  
  const callSignalCallback = useRef<((signal: any) => void) | null>(null);

  useEffect(() => {
    fetchHistory();
    setupStomp();

    return () => {
      if (stompClientRef.current) {
        stompClientRef.current.deactivate();
      }
    };
  }, [user.id]);

  const fetchHistory = async () => {
    if (!currentUserId || !user.id) return;
    try {
      const res = await api.get(`/api/chat/history/${user.id}`);
      const history = res.data.map((m: any) => ({
        id: m.id,
        text: m.message,
        sender: m.senderId === currentUserId ? "me" : "them",
        time: m.timestamp ? new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "Recently",
        status: m.isRead ? "read" : "delivered",
        type: m.messageType || "text",
        mediaUrl: m.mediaUrl || null
      }));
      setMessages(history);
    } catch(e) {
      console.error("Failed to fetch history", e);
    }
  };

  const setupStomp = async () => {
    if (!currentUserId) return;
    const token = await auth.currentUser?.getIdToken();
    
    const client = new Client({
      brokerURL: `ws://localhost:8082/ws`, // production should use wss:// domain
      connectHeaders: {
        Authorization: `Bearer ${token}`,
      },
      onConnect: () => {
        client.subscribe(`/topic/messages/${currentUserId}`, (message) => {
          const msgData = JSON.parse(message.body);
          if (msgData.senderId === user.id || msgData.senderId === currentUserId) {
            
            // Auto ACK message as read if received from the person we are chatting with
            if (msgData.senderId === user.id) {
               client.publish({
                 destination: "/app/chat.read",
                 headers: { Authorization: `Bearer ${token}` },
                 body: JSON.stringify({ readerId: currentUserId, senderId: user.id })
               });
            }

            setMessages(prev => {
              // Replace optimistic message or add new broadcasted one
              const existingIndex = prev.findIndex(m => m.id === msgData.id);
              const formattedMsg = {
                id: msgData.id,
                text: msgData.message,
                sender: (msgData.senderId === currentUserId ? "me" : "them") as "me" | "them",
                time: msgData.timestamp ? new Date(msgData.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "Now",
                status: (msgData.isRead ? "read" : "delivered") as any,
                type: (msgData.messageType || "text") as any,
                mediaUrl: msgData.mediaUrl || null
              };

              if (existingIndex !== -1) {
                const updated = [...prev];
                updated[existingIndex] = formattedMsg;
                return updated;
              }
              return [...prev, formattedMsg];
            });
          }
        });

        // Listen for Read Receipts to change single ticks to double ticks
        client.subscribe(`/topic/messages.read/${currentUserId}`, (message) => {
          const data = JSON.parse(message.body);
          if (data.readerId === user.id && data.isRead) {
            setMessages(prev => prev.map(m => 
              m.sender === "me" && m.status !== "read" 
                ? { ...m, status: "read" as any } 
                : m
            ));
          }
        });

        // Emit initial read receipt query for historical backlog when first connecting
        client.publish({
          destination: "/app/chat.read",
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify({ readerId: currentUserId, senderId: user.id })
        });

        // Subscribe to incoming calls
        client.subscribe(`/topic/calls/${currentUserId}`, (message) => {
          const signal = JSON.parse(message.body);
          if (signal.senderId !== user.id) return;

          if (signal.type === "offer") {
            setActiveCall({
              type: signal.data.type === "video" ? "video" : "voice",
              isIncoming: true,
              incomingOffer: signal.data
            });
          } else if (callSignalCallback.current) {
            callSignalCallback.current(signal);
          }
        });
      },
    });
    
    client.activate();
    stompClientRef.current = client;
  };

  const sendMessage = async () => {
    if (!input.trim() || !user.id || !currentUserId) return;
    const msgData = input;
    setInput("");
    
    // Optimistic UI updates
    const tempId = Date.now().toString();
    setMessages((prev) => [
      ...prev,
      { id: tempId, text: msgData, sender: "me" as "me", time: "Now", status: "sending" as "sending" },
    ]);

    try {
      const token = await auth.currentUser?.getIdToken();
      const payload = {
        id: tempId.toString(),
        senderId: currentUserId,
        receiverId: user.id,
        message: msgData,
        messageType: "text",
        mediaUrl: null
      };

      if (stompClientRef.current?.connected) {
        stompClientRef.current.publish({
          destination: "/app/chat.send",
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify(payload)
        });
      } else {
        // Fallback to HTTP if socket disconnected
        await api.post(`/api/chat/send/${user.id}`, { message: msgData, messageType: "text" });
        fetchHistory();
      }
    } catch(e) {
      console.error("Failed to send message", e);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        setIsRecording(false);
        if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
        
        // Final chunks are often delivered immediately before this event.
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' }); 
        audioChunksRef.current = []; 
        
        if (streamRef.current) {
           streamRef.current.getTracks().forEach(track => track.stop());
           streamRef.current = null;
        }

        if (recordingTime < 1) return;
        
        await uploadAudioAndSend(audioBlob);
      };

      mediaRecorder.onstart = () => {
        setIsRecording(true);
        setRecordingTime(0);
        recordingTimerRef.current = setInterval(() => {
          setRecordingTime(prev => prev + 1);
        }, 1000);
      };

      mediaRecorder.start(100); 
    } catch (err) {
      console.error("Mic access denied", err);
      toast.error("Microphone access denied or unavailable.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
       // Only stop the recorder, let the onstop handler process the blob
       mediaRecorderRef.current.stop();
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const uploadAudioAndSend = async (blob: Blob) => {
    if (!currentUserId || !user.id) return;
    
    const tempId = Date.now().toString();
    setMessages(prev => [
      ...prev,
      { id: tempId, text: "", sender: "me" as "me", time: "Now", status: "sending" as "sending", type: "audio", mediaUrl: URL.createObjectURL(blob) },
    ]);

    try {
      const formData = new FormData();
      formData.append("file", blob, `audio_${tempId}.webm`);

      // Upload to your own backend (Proxy to Catbox)
      const uploadRes = await api.post("/api/media/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      const downloadUrl = uploadRes.data.mediaUrl;

      const token = await auth.currentUser?.getIdToken();
      const payload = {
        senderId: currentUserId,
        receiverId: user.id,
        message: "🎵 Voice Message",
        messageType: "audio",
        mediaUrl: downloadUrl
      };

      if (stompClientRef.current?.connected) {
        stompClientRef.current.publish({
          destination: "/app/chat.send",
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify(payload)
        });
      } else {
        await api.post(`/api/chat/send/${user.id}`, payload);
        fetchHistory();
      }
    } catch(e: any) {
      console.error("Failed to upload audio", e);
      toast.error(`Audio upload failed: ${e.message}`);
      setMessages(prev => prev.filter(m => m.id !== tempId));
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: "image" | "video") => {
    const file = e.target.files?.[0];
    if (!file || !currentUserId || !user.id) return;

    const tempId = Date.now().toString();
    const localUrl = URL.createObjectURL(file);
    
    // Optimistic UI
    setMessages(prev => [
      ...prev,
      { id: tempId, text: "", sender: "me" as "me", time: "Now", status: "sending" as "sending", type: type as any, mediaUrl: localUrl },
    ]);

    try {
      const formData = new FormData();
      formData.append("file", file);

      // Upload to your own backend (Proxy to Catbox)
      const uploadRes = await api.post("/api/media/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      const downloadUrl = uploadRes.data.mediaUrl;

      const token = await auth.currentUser?.getIdToken();
      const payload = {
        senderId: currentUserId,
        receiverId: user.id,
        message: type === "image" ? "📷 Image" : "🎥 Video",
        messageType: type,
        mediaUrl: downloadUrl
      };

      if (stompClientRef.current?.connected) {
        stompClientRef.current.publish({
          destination: "/app/chat.send",
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify(payload)
        });
      } else {
        await api.post(`/api/chat/send/${user.id}`, payload);
        fetchHistory();
      }
    } catch(err: any) {
      console.error("Upload failed", err);
      toast.error(`${type} upload failed. ${err.message}`);
      setMessages(prev => prev.filter(m => m.id !== tempId));
    }
  };

  const sendIcebreaker = (text: string) => {
    setInput(text);
    setShowIcebreaker(false);
  };

  const sendCallSignal = (signalData: any) => {
    if (!stompClientRef.current?.connected || !currentUserId || !user.id) return;
    
    auth.currentUser?.getIdToken().then(token => {
      stompClientRef.current?.publish({
        destination: "/app/call.signal",
        headers: { Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          ...signalData,
          senderId: currentUserId,
          receiverId: user.id
        })
      });
    });
  };

  if (activeCall) {
    return (
      <CallScreen 
        user={user} 
        currentUserId={currentUserId!} 
        type={activeCall.type} 
        isIncoming={activeCall.isIncoming} 
        incomingOffer={activeCall.incomingOffer} 
        onEnd={() => setActiveCall(null)}
        sendSignal={sendCallSignal}
        onSignalReceived={(cb) => {
          callSignalCallback.current = cb;
          return () => { callSignalCallback.current = null; };
        }}
      />
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-4 py-3 border-b border-border">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
            <ArrowLeft className="h-5 w-5 text-primary" />
          </button>
          <div className="relative">
            {user.realImageUrls && user.realImageUrls.length > 0 ? (
              <img src={user.realImageUrls[0]} alt={user.name} className="h-9 w-9 rounded-full object-cover" />
            ) : (
              <div className="h-9 w-9 rounded-full" style={getAvatarStyle(user.img)} />
            )}
            {user.online && (
              <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-background bg-green-500" />
            )}
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground">{user.name}</p>
            <p className="text-[10px] text-muted-foreground">
              {isTyping ? (
                <span className="text-accent font-medium">typing...</span>
              ) : user.online ? "Online now" : "Last seen recently"}
            </p>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => setActiveCall({ type: "voice", isIncoming: false })} className="flex h-8 w-8 items-center justify-center rounded-full bg-card shadow-card">
              <Phone className="h-4 w-4 text-primary" />
            </button>
            <button onClick={() => setActiveCall({ type: "video", isIncoming: false })} className="flex h-8 w-8 items-center justify-center rounded-full bg-card shadow-card">
              <Video className="h-4 w-4 text-primary" />
            </button>
            <button onClick={() => setDisappearingMode(!disappearingMode)}
              className={`flex h-8 w-8 items-center justify-center rounded-full transition-all ${disappearingMode ? "gradient-royal" : "bg-card shadow-card"}`}>
              <Timer className={`h-4 w-4 ${disappearingMode ? "text-accent-foreground" : "text-muted-foreground"}`} />
            </button>
          </div>
        </div>
        <div className="mt-2 flex items-center justify-center gap-1.5">
          <Shield className="h-3 w-3 text-muted-foreground" />
          <span className="text-[9px] text-muted-foreground">End-to-end encrypted</span>
        </div>
      </header>

      {/* Messages */}
      <main className="flex-1 px-4 py-4 space-y-3 overflow-y-auto">
        {messages.length === 0 && (
          <div className="text-center text-muted-foreground text-sm py-4">
            No messages yet. Send an icebreaker!
          </div>
        )}
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"} animate-fade-up`}>
            {msg.isScreenshotAlert ? (
              <div className="max-w-[85%] rounded-2xl px-3.5 py-2.5 bg-destructive/10 border border-destructive/20">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-3.5 w-3.5 text-destructive" />
                  <p className="text-xs text-destructive font-medium">{msg.text}</p>
                </div>
              </div>
            ) : (
              <div className={`max-w-[75%] rounded-2xl px-3.5 py-2.5 ${
                msg.sender === "me"
                  ? "gradient-royal text-accent-foreground rounded-br-md"
                  : "bg-card text-foreground shadow-card rounded-bl-md"
              }`}>
                {msg.type === "audio" && msg.mediaUrl ? (
                  <audio controls src={msg.mediaUrl} className="h-10 w-[200px]" />
                ) : msg.type === "image" && msg.mediaUrl ? (
                  <img src={msg.mediaUrl} alt="Image" className="max-w-full rounded-xl mt-1 object-cover max-h-[250px]" />
                ) : msg.type === "video" && msg.mediaUrl ? (
                  <video controls src={msg.mediaUrl} className="max-w-full rounded-xl mt-1 max-h-[250px]" />
                ) : (
                  <p className="text-sm leading-relaxed">{msg.text}</p>
                )}
                <div className="flex items-center gap-1 mt-1 justify-end">
                  <span className={`text-[9px] ${msg.sender === "me" ? "text-accent-foreground/60" : "text-muted-foreground"}`}>
                    {msg.time}
                  </span>
                  {msg.sender === "me" && msg.status && (
                    msg.status === "read" ? <CheckCheck className="h-3 w-3 text-accent-foreground/80" /> : <Check className="h-3 w-3 text-accent-foreground/40" />
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </main>

      {/* Icebreaker panel */}
      {showIcebreaker && (
        <div className="px-4 pb-2 animate-fade-up">
          <div className="rounded-2xl bg-card shadow-elevated p-3">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-accent" />
              <span className="text-xs font-semibold text-foreground">Icebreakers</span>
            </div>
            <div className="space-y-1.5">
              {ICEBREAKERS.map((text, i) => (
                <button key={i} onClick={() => sendIcebreaker(text)}
                  className="w-full text-left text-xs text-muted-foreground hover:text-foreground py-1.5 px-2 rounded-lg hover:bg-secondary transition-colors">
                  {text}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Input */}
      <div className="sticky bottom-0 bg-background/80 backdrop-blur-lg border-t border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <button onClick={() => setShowIcebreaker(!showIcebreaker)}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card flex-shrink-0">
            <Sparkles className={`h-4 w-4 ${showIcebreaker ? "text-accent" : "text-muted-foreground"}`} />
          </button>
          
          <button onClick={() => fileInputRef.current?.click()}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card flex-shrink-0">
            <Image className="h-4 w-4 text-muted-foreground" />
          </button>

          <button onClick={() => videoInputRef.current?.click()}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card flex-shrink-0">
            <Video className="h-4 w-4 text-muted-foreground" />
          </button>

          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" 
            onChange={(e) => handleFileUpload(e, "image")} />
          
          <input type="file" ref={videoInputRef} className="hidden" accept="video/*" 
            onChange={(e) => handleFileUpload(e, "video")} />

          <div className="flex-1 flex items-center bg-card rounded-2xl shadow-card px-3 transition-all relative">
            {isRecording ? (
              <div className="flex-1 py-2.5 flex items-center gap-3 animate-pulse">
                <span className="h-2 w-2 rounded-full bg-destructive animate-ping" />
                <span className="text-sm font-medium text-destructive">{formatTime(recordingTime)}</span>
              </div>
            ) : (
              <input value={input} onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                placeholder="Type a message..."
                className="flex-1 bg-transparent py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" />
            )}
          </div>
          
          {input.trim() ? (
            <button onClick={sendMessage} className="flex h-9 w-9 items-center justify-center rounded-full gradient-warm shadow-card flex-shrink-0 animate-in zoom-in">
              <Send className="h-4 w-4 text-accent-foreground" />
            </button>
          ) : (
            <button 
              onMouseDown={startRecording}
              onMouseUp={stopRecording}
              onTouchStart={startRecording}
              onTouchEnd={stopRecording}
              className={`flex h-9 w-9 items-center justify-center rounded-full shadow-card flex-shrink-0 transition-colors cursor-pointer select-none ${isRecording ? "bg-destructive text-destructive-foreground animate-pulse" : "bg-card text-primary"}`}
            >
              <Mic className="h-4.5 w-4.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatRoom;

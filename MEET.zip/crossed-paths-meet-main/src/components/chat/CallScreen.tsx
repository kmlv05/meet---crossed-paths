import { useState, useEffect, useRef } from "react";
import { Phone, PhoneOff, Video, VideoOff, Mic, MicOff, Volume2, X } from "lucide-react";

interface CallScreenProps {
  user: any;
  currentUserId: string;
  type: "voice" | "video";
  isIncoming?: boolean;
  incomingOffer?: any;
  onEnd: () => void;
  sendSignal: (signal: any) => void;
  onSignalReceived: (callback: (signal: any) => void) => () => void;
}

const configuration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ]
};

const CallScreen = ({ user, type, isIncoming, incomingOffer, onEnd, sendSignal, onSignalReceived }: CallScreenProps) => {
  const [callState, setCallState] = useState<"ringing" | "connected" | "ended">("ringing");
  const [isAccepted, setIsAccepted] = useState(!isIncoming);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [duration, setDuration] = useState(0);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!isAccepted) return;
    
    const initCall = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: type === "video"
        });
        localStreamRef.current = stream;
        if (localVideoRef.current) localVideoRef.current.srcObject = stream;

        const pc = new RTCPeerConnection(configuration);
        pcRef.current = pc;

        stream.getTracks().forEach(track => pc.addTrack(track, stream));

        pc.onicecandidate = (event) => {
          if (event.candidate) {
            sendSignal({ type: "candidate", data: event.candidate });
          }
        };

        pc.ontrack = (event) => {
          if (remoteVideoRef.current) {
            remoteVideoRef.current.srcObject = event.streams[0];
            setCallState("connected");
          }
        };

        if (isIncoming && incomingOffer) {
          await pc.setRemoteDescription(new RTCSessionDescription(incomingOffer));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          sendSignal({ type: "answer", data: answer });
        } else {
          // If not incoming, we wait for someone to answer or just create the offer if we are the initiator
          // In this simplified logic, we always create an offer if we aren't handling an incoming one
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          sendSignal({ type: "offer", data: offer });
        }
      } catch (err) {
        console.error("WebRTC Error:", err);
        setCallState("ended");
        setTimeout(onEnd, 2000);
      }
    };

    initCall();

    const unsubscribe = onSignalReceived(async (signal) => {
      if (signal.type === "reject") {
        setCallState("ended");
        setTimeout(onEnd, 1000);
        return;
      }
      if (!pcRef.current) return;
      try {
        if (signal.type === "answer") {
          await pcRef.current.setRemoteDescription(new RTCSessionDescription(signal.data));
          setCallState("connected");
        } else if (signal.type === "candidate") {
          await pcRef.current.addIceCandidate(new RTCIceCandidate(signal.data));
        } else if (signal.type === "hangup") {
          setCallState("ended");
          setTimeout(onEnd, 1000);
        }
      } catch (err) {
        console.error("Signaling error:", err);
      }
    });

    return () => {
      unsubscribe();
      localStreamRef.current?.getTracks().forEach(t => t.stop());
      pcRef.current?.close();
    };
  }, []);

  useEffect(() => {
    if (callState === "connected") {
      const interval = setInterval(() => setDuration((d) => d + 1), 1000);
      return () => clearInterval(interval);
    }
  }, [callState]);

  const handleEnd = () => {
    sendSignal({ type: "hangup" });
    setCallState("ended");
    setTimeout(onEnd, 1000);
  };

  const formatDuration = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-between bg-black text-white">
      {/* Videos Section */}
      <div className="absolute inset-0 z-0 bg-gray-900">
        {type === "video" ? (
          <>
            <video ref={remoteVideoRef} autoPlay playsInline className="h-full w-full object-cover" />
            <video ref={localVideoRef} autoPlay playsInline muted className="absolute top-6 right-6 w-28 h-40 rounded-xl object-cover border border-white/20 shadow-2xl z-20" />
          </>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center opacity-20">
             <div className="h-64 w-64 rounded-full bg-gradient-to-br from-accent to-primary blur-3xl" />
          </div>
        )}
      </div>

      {/* Profile Overlay (Visible during ringing or voice call) */}
      <div className="relative z-10 flex flex-col items-center pt-24 text-center">
        {(callState === "ringing" || type === "voice") && (
          <div className="relative mb-6">
            <div className={`h-32 w-32 rounded-full border-4 border-white/10 p-1 ${callState === "ringing" ? "animate-pulse" : ""}`}>
              <img src={user.realImageUrls?.[0] || ""} className="h-full w-full rounded-full object-cover" alt={user.name} />
            </div>
          </div>
        )}
        
        <h2 className="text-3xl font-bold tracking-tight drop-shadow-md">{user.name}</h2>
        <p className="mt-2 text-lg font-medium text-white/70">
          {callState === "ringing" && (isIncoming ? "Incoming..." : "Calling...")}
          {callState === "connected" && formatDuration(duration)}
          {callState === "ended" && "Call ended"}
        </p>
      </div>

      {/* Incoming Call UI */}
      {isIncoming && !isAccepted && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-gray-900/95 backdrop-blur-xl">
          <div className="mb-8 flex flex-col items-center">
            <div className="mb-6 h-32 w-32 animate-pulse rounded-full border-4 border-accent p-1">
               <img src={user.realImageUrls?.[0] || ""} className="h-full w-full rounded-full object-cover" alt={user.name} />
            </div>
            <h2 className="text-3xl font-bold">{user.name}</h2>
            <p className="mt-2 text-white/60">Incoming {type} call...</p>
          </div>
          
          <div className="flex gap-12">
            <button
              onClick={handleEnd}
              className="flex h-20 w-20 items-center justify-center rounded-full bg-red-500 shadow-lg transition-transform hover:scale-110 active:scale-95"
            >
              <PhoneOff className="h-8 w-8" />
            </button>
            <button
              onClick={() => setIsAccepted(true)}
              className="flex h-20 w-20 items-center justify-center rounded-full bg-green-500 shadow-lg transition-transform hover:scale-110 active:scale-95"
            >
              <Phone className="h-8 w-8" />
            </button>
          </div>
        </div>
      )}

      {/* Controls Container */}
      <div className="relative z-10 w-full max-w-md px-8 pb-16">
        <div className="flex flex-col gap-8">
          {callState !== "ended" && isAccepted && (
            <div className="flex items-center justify-around rounded-3xl bg-white/10 p-4 backdrop-blur-md">
              <button onClick={() => setIsMuted(!isMuted)} className={`flex h-12 w-12 items-center justify-center rounded-full transition-colors ${isMuted ? "bg-white text-black" : "hover:bg-white/20"}`}>
                {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
              </button>
              
              {type === "video" && (
                <button onClick={() => setIsVideoOff(!isVideoOff)} className={`flex h-12 w-12 items-center justify-center rounded-full transition-colors ${isVideoOff ? "bg-white text-black" : "hover:bg-white/20"}`}>
                  {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
                </button>
              )}
              
              <button className="flex h-12 w-12 items-center justify-center rounded-full hover:bg-white/20">
                <Volume2 className="h-6 w-6" />
              </button>
            </div>
          )}

          <div className="flex justify-center">
            {isAccepted || !isIncoming ? (
              <button
                onClick={handleEnd}
                className={`flex h-20 w-20 items-center justify-center rounded-full shadow-2xl transition-transform hover:scale-110 active:scale-95 ${callState === "ended" ? "bg-gray-600" : "bg-red-500"}`}
              >
                {callState === "ended" ? <X className="h-8 w-8" /> : <PhoneOff className="h-8 w-8" />}
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CallScreen;

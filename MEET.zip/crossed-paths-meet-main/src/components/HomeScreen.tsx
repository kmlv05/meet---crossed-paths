import { useState, useEffect, useMemo } from "react";
import { Heart, MessageCircle, User, Bell, Star, Crown, SlidersHorizontal, Loader2 } from "lucide-react";
import { MOCK_CROSSED } from "@/data/mockData"; // Keep crossed mock for UI placeholder if needed
import SwipeCard from "@/components/home/SwipeCard";
import LikesScreen from "@/components/home/LikesScreen";
import ClubScreen from "@/components/home/ClubScreen";
import ChatList from "@/components/chat/ChatList";
import ChatRoom from "@/components/chat/ChatRoom";
import ProfileScreen from "@/components/profile/ProfileScreen";
import UserProfileModal from "@/components/profile/UserProfileModal";
import PremiumModal from "@/components/premium/PremiumModal";
import MatchScreen from "@/components/MatchScreen";
import NotificationsScreen from "@/components/NotificationsScreen";
import FiltersModal from "@/components/FiltersModal";
import { api } from "@/lib/api";
import { toast } from "sonner";
import { auth } from "@/lib/firebase";

type Tab = "home" | "likes" | "club" | "chat" | "profile";

const HomeScreen = () => {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [activeUsers, setActiveUsers] = useState<any[]>([]);
  const [matches, setMatches] = useState<any[]>([]);
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());
  const [passedIds, setPassedIds] = useState<Set<string>>(new Set());
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [chatUser, setChatUser] = useState<any | null>(null);
  const [showPremium, setShowPremium] = useState(false);
  const [matchedUser, setMatchedUser] = useState<any | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lastUserId, setLastUserId] = useState<string | null>(null);
  const [hasMoreUsers, setHasMoreUsers] = useState(true);

  useEffect(() => {
    fetchNearbyUsers(false);
    fetchMatches();
    
    // Attempt tracking latest coordinates on load quietly
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          api.put(`/api/users/location?lat=${pos.coords.latitude}&lng=${pos.coords.longitude}`).catch(() => {});
        },
        () => {}
      );
    }
  }, []);

  const fetchNearbyUsers = async (isLoadMore = false) => {
    if (isLoadMore && (!hasMoreUsers || loading)) return;
    
    try {
      if (!isLoadMore) setLoading(true);
      
      const endpoint = isLoadMore && lastUserId 
        ? `/api/users/nearby?lastUserId=${lastUserId}` 
        : `/api/users/nearby`;
        
      const res = await api.get(endpoint);
      
      const apiUsers = res.data.map((u: any, index: number) => ({
        id: u.id,
        name: u.name || "User",
        age: u.age || 25,
        distance: "Nearby",
        img: index, // Using index as fallback mock avatar if no imageUrl
        realImageUrls: u.imageUrls || [],
        bio: u.bio || "",
        interests: u.interests || [],
        personalityTags: ["New User"],
        online: true,
      }));
      
      if (apiUsers.length > 0) {
        setLastUserId(apiUsers[apiUsers.length - 1].id);
        if (isLoadMore) {
          setActiveUsers((prev) => [...prev, ...apiUsers]);
        } else {
          setActiveUsers(apiUsers);
        }
      } else {
        setHasMoreUsers(false); // Reached end of DB
      }
    } catch (e: any) {
      toast.error("Failed to load users: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchMatches = async () => {
     try {
       const res = await api.get("/api/match/list");
       const currentUserId = auth.currentUser?.uid;
       const matchObjects = res.data;
       
       const loadedMatches = [];
       // Fetch profile of the other user in each match
       for (const m of matchObjects) {
         const otherId = m.user1Id === currentUserId ? m.user2Id : m.user1Id;
         // Wait, the API doesn't return other user profile directly, we must do a fetch for each.
         // For now, let's keep it simple and just do a fallback. A production app would have a batched endpoint.
         try {
           const profileRes = await api.get(`/api/users/profile/${otherId}`);
           const profile = profileRes.data;

           let lastMessage = undefined;
           try {
              const historyRes = await api.get(`/api/chat/history/${otherId}`);
              const history = historyRes.data;
              if (history && history.length > 0) {
                 const lastMsg = history[history.length - 1];
                 lastMessage = {
                    text: lastMsg.message,
                    time: lastMsg.timestamp ? new Date(lastMsg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "Recently",
                    unread: history.filter((m: any) => m.senderId === otherId && !m.isRead).length,
                    isMine: lastMsg.senderId === currentUserId,
                    status: lastMsg.isRead ? "read" : "delivered"
                 };
              }
           } catch (e) {
              console.warn("Failed fetching history for last message snippet", e);
           }

           loadedMatches.push({
             id: otherId,
             name: profile.name || "User",
             age: profile.age || 25,
             img: 5, // Fallback index for now
             realImageUrls: profile.imageUrls || [],
             bio: profile.bio || "It's a match!",
             interests: profile.interests || [],
             lastMessage: lastMessage
           });
         } catch (err) {
           console.error(`Failed to fetch profile for match user ${otherId}`, err);
         }
       }
       setMatches(loadedMatches);
     } catch(e) {
        console.error("Match fetch failed", e);
     }
  };

  const availableUsers = useMemo(
    () => activeUsers.filter((u) => !likedIds.has(String(u.id)) && !passedIds.has(String(u.id))),
    [activeUsers, likedIds, passedIds]
  );

  useEffect(() => {
    // Infinite swiping: Pre-fetch next page when deck gets low
    if (availableUsers.length <= 3 && hasMoreUsers && !loading) {
      fetchNearbyUsers(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [availableUsers.length, hasMoreUsers, loading]);

  const handleLike = async (id: string | number) => {
    const stringId = String(id);
    setLikedIds((prev) => new Set(prev).add(stringId));
    
    try {
       const res = await api.post(`/api/match/like/${stringId}`);
       if (res.data.isMatch) {
         const user = activeUsers.find((u) => String(u.id) === stringId);
         if (user) setMatchedUser(user);
         fetchMatches(); // refresh matches
       }
    } catch(e) {
       toast.error("Failed to like user");
    }
  };

  const handlePass = async (id: string | number) => {
    const stringId = String(id);
    setPassedIds((prev) => new Set(prev).add(stringId));
    try {
       await api.post(`/api/match/dislike/${stringId}`);
    } catch(e) {}
  };

  const handleSuperLike = (id: string | number) => {
    handleLike(id);
  };

  if (chatUser) {
    return <ChatRoom user={chatUser} onBack={() => { setChatUser(null); fetchMatches(); }} />;
  }

  if (showNotifications) {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3">
          <div className="flex items-center justify-between">
            <h1 className="font-display text-xl font-bold text-foreground">Notifications</h1>
            <button onClick={() => setShowNotifications(false)} className="text-sm font-medium text-primary">Done</button>
          </div>
        </header>
        <main className="flex-1 pb-6">
          <NotificationsScreen />
        </main>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      {activeTab === "home" && (
        <header className="sticky top-0 z-20 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3">
          <div className="flex items-center justify-between">
            <h1 className="font-display text-2xl font-bold text-primary">
              Meet <span className="text-accent">❤️</span>
            </h1>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowFilters(true)}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card"
              >
                <SlidersHorizontal className="h-4 w-4 text-primary" />
              </button>
              <button
                onClick={() => setShowNotifications(true)}
                className="relative flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card"
              >
                <Bell className="h-4 w-4 text-primary" />
              </button>
              <button onClick={() => setShowPremium(true)} className="flex h-9 w-9 items-center justify-center rounded-full gradient-gold shadow-card">
                <Crown className="h-4 w-4 text-accent-foreground" />
              </button>
            </div>
          </div>
        </header>
      )}

      {/* Content */}
      <main className="flex-1 pb-20">
        {activeTab === "home" && (
          <div className="relative px-4 pt-2" style={{ height: "calc(100vh - 160px)" }}>
            {loading ? (
               <div className="flex flex-col items-center justify-center h-full">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
               </div>
            ) : availableUsers.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Heart className="h-16 w-16 text-muted-foreground mb-4" />
                <h3 className="font-display text-lg font-bold text-foreground mb-1">No more profiles</h3>
                <p className="text-sm text-muted-foreground">Check back later for new people nearby!</p>
              </div>
            ) : (
              <>
                {availableUsers.slice(0, 3).reverse().map((user, i) => (
                  <SwipeCard
                    key={user.id}
                    user={user}
                    isTop={i === availableUsers.slice(0, 3).reverse().length - 1}
                    onLike={() => handleLike(user.id)}
                    onPass={() => handlePass(user.id)}
                    onSuperLike={() => handleSuperLike(user.id)}
                    onViewProfile={() => setSelectedUser(user)}
                  />
                ))}
              </>
            )}
          </div>
        )}

        {activeTab === "likes" && (
          <LikesScreen
            likedIds={new Set(Array.from(likedIds).map((s) => Number(s)))} // Fallback mapping for typing
            allUsers={activeUsers}
            onViewProfile={setSelectedUser}
            onShowPremium={() => setShowPremium(true)}
          />
        )}

        {activeTab === "club" && <ClubScreen />}

        {activeTab === "chat" && (
          <ChatList matches={matches} onOpenChat={setChatUser} />
        )}

        {activeTab === "profile" && <ProfileScreen />}
      </main>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 glass border-t border-border px-4 py-2.5 z-20">
        <div className="flex justify-around max-w-md mx-auto">
          {([
            { key: "home" as Tab, icon: Heart, label: "Home" },
            { key: "likes" as Tab, icon: Heart, label: "Likes" },
            { key: "club" as Tab, icon: Star, label: "Club" },
            { key: "chat" as Tab, icon: MessageCircle, label: "Chat", badge: matches.length > 0 ? matches.length : undefined },
            { key: "profile" as Tab, icon: User, label: "Profile" },
          ]).map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className="relative flex flex-col items-center gap-0.5"
            >
              <tab.icon className={`h-5 w-5 ${activeTab === tab.key ? "text-primary" : "text-muted-foreground"} ${tab.key === "likes" && activeTab === tab.key ? "fill-primary" : ""}`} />
              <span className={`text-[10px] font-medium ${activeTab === tab.key ? "text-primary" : "text-muted-foreground"}`}>
                {tab.label}
              </span>
              {tab.badge && (
                <span className="absolute -top-1 -right-2 flex h-4 w-4 items-center justify-center rounded-full gradient-warm text-[9px] font-bold text-accent-foreground">
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* Modals */}
      {selectedUser && (
        <UserProfileModal
          user={selectedUser}
          isLiked={likedIds.has(String(selectedUser.id))}
          onClose={() => setSelectedUser(null)}
          onLike={() => handleLike(selectedUser.id)}
          onSuperLike={() => handleSuperLike(selectedUser.id)}
          onMessage={() => { setChatUser(selectedUser); setSelectedUser(null); }}
        />
      )}
      {showPremium && <PremiumModal onClose={() => setShowPremium(false)} />}
      {matchedUser && (
        <MatchScreen
          user={matchedUser}
          onMessage={() => { setChatUser(matchedUser); setMatchedUser(null); }}
          onClose={() => setMatchedUser(null)}
        />
      )}
      {showFilters && (
        <FiltersModal
          onClose={() => setShowFilters(false)}
          onApply={() => setShowFilters(false)}
        />
      )}
    </div>
  );
};

export default HomeScreen;

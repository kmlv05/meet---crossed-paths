import { useState } from "react";
import { X, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FiltersModalProps {
  onClose: () => void;
  onApply: (filters: FilterState) => void;
}

export interface FilterState {
  ageRange: [number, number];
  distance: number;
  gender: string;
  showOnline: boolean;
  city: string;
  interests: string[];
}

const CITIES = ["All Cities", "Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Pune", "Jaipur"];
const FILTER_INTERESTS = ["Travel", "Music", "Tech", "Fitness", "Photography", "Coffee", "Art", "Gaming"];

const FiltersModal = ({ onClose, onApply }: FiltersModalProps) => {
  const [ageRange, setAgeRange] = useState<[number, number]>([18, 35]);
  const [distance, setDistance] = useState(10);
  const [gender, setGender] = useState("Everyone");
  const [showOnline, setShowOnline] = useState(false);
  const [city, setCity] = useState("All Cities");
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  const toggleInterest = (i: string) => {
    setSelectedInterests((prev) =>
      prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i]
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm animate-fade-up" onClick={onClose}>
      <div className="w-full max-w-lg bg-background rounded-t-3xl px-5 pt-6 pb-8 max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="h-5 w-5 text-primary" />
            <h2 className="font-display text-xl font-bold text-foreground">Filters</h2>
          </div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-full bg-card shadow-card">
            <X className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Age Range */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-semibold text-foreground">Age Range</p>
              <span className="text-sm text-accent font-medium">{ageRange[0]} – {ageRange[1]}</span>
            </div>
            <div className="flex gap-3">
              <div className="flex-1">
                <label className="text-[10px] text-muted-foreground font-medium mb-1 block">Min</label>
                <input type="range" min={16} max={60} value={ageRange[0]}
                  onChange={(e) => setAgeRange([Math.min(Number(e.target.value), ageRange[1]), ageRange[1]])}
                  className="w-full accent-primary" />
              </div>
              <div className="flex-1">
                <label className="text-[10px] text-muted-foreground font-medium mb-1 block">Max</label>
                <input type="range" min={16} max={60} value={ageRange[1]}
                  onChange={(e) => setAgeRange([ageRange[0], Math.max(Number(e.target.value), ageRange[0])])}
                  className="w-full accent-primary" />
              </div>
            </div>
          </div>

          {/* Distance */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-semibold text-foreground">Distance</p>
              <span className="text-sm text-accent font-medium">{distance} km</span>
            </div>
            <input type="range" min={1} max={50} value={distance}
              onChange={(e) => setDistance(Number(e.target.value))}
              className="w-full accent-primary" />
          </div>

          {/* Gender */}
          <div>
            <p className="text-sm font-semibold text-foreground mb-3">Show me</p>
            <div className="grid grid-cols-3 gap-2">
              {["Women", "Men", "Everyone"].map((g) => (
                <button key={g} onClick={() => setGender(g)}
                  className={`rounded-xl py-2.5 text-sm font-medium transition-all ${
                    gender === g ? "gradient-royal text-accent-foreground shadow-card" : "bg-card text-muted-foreground shadow-card"
                  }`}>{g}</button>
              ))}
            </div>
          </div>

          {/* City */}
          <div>
            <p className="text-sm font-semibold text-foreground mb-3">City</p>
            <div className="flex flex-wrap gap-2">
              {CITIES.map((c) => (
                <button key={c} onClick={() => setCity(c)}
                  className={`rounded-full px-4 py-2 text-xs font-medium transition-all ${
                    city === c ? "gradient-royal text-accent-foreground" : "bg-card shadow-card text-foreground"
                  }`}>{c}</button>
              ))}
            </div>
          </div>

          {/* Interests */}
          <div>
            <p className="text-sm font-semibold text-foreground mb-3">Interests</p>
            <div className="flex flex-wrap gap-2">
              {FILTER_INTERESTS.map((i) => (
                <button key={i} onClick={() => toggleInterest(i)}
                  className={`rounded-full px-4 py-2 text-xs font-medium transition-all ${
                    selectedInterests.includes(i) ? "gradient-warm text-accent-foreground" : "bg-card shadow-card text-foreground"
                  }`}>{i}</button>
              ))}
            </div>
          </div>

          {/* Online only */}
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-foreground">Online only</p>
            <button onClick={() => setShowOnline(!showOnline)}
              className={`relative w-12 h-7 rounded-full transition-all ${showOnline ? "gradient-royal" : "bg-secondary"}`}>
              <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-card shadow-card transition-transform ${showOnline ? "translate-x-5" : "translate-x-0.5"}`} />
            </button>
          </div>
        </div>

        <div className="flex gap-3 mt-8">
          <Button onClick={() => { setAgeRange([18, 35]); setDistance(10); setGender("Everyone"); setShowOnline(false); setCity("All Cities"); setSelectedInterests([]); }}
            variant="outline" className="flex-1 h-12 rounded-2xl text-sm font-medium">Reset</Button>
          <Button onClick={() => onApply({ ageRange, distance, gender, showOnline, city, interests: selectedInterests })}
            className="flex-1 h-12 rounded-2xl gradient-royal text-accent-foreground text-sm font-semibold border-0 shadow-elevated hover:opacity-90 transition-opacity">Apply Filters</Button>
        </div>
      </div>
    </div>
  );
};

export default FiltersModal;

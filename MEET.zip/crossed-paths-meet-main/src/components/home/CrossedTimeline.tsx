import { Heart, MapPin, Star, X, Repeat } from "lucide-react";
import { getAvatarStyle, type MockUser } from "@/data/mockData";

interface CrossedTimelineProps {
  users: MockUser[];
  likedIds: Set<number>;
  onLike: (id: number) => void;
  onSuperLike: (id: number) => void;
  onViewProfile: (user: MockUser) => void;
}

const CrossedTimeline = ({ users, likedIds, onLike, onSuperLike, onViewProfile }: CrossedTimelineProps) => {
  return (
    <div className="px-5 pt-3 space-y-3">
      <p className="text-sm text-muted-foreground">People you've crossed paths with recently</p>

      {users.map((user, i) => (
        <div
          key={user.id}
          className="flex items-center gap-3 rounded-2xl bg-card p-3.5 shadow-card animate-slide-in cursor-pointer"
          style={{ animationDelay: `${i * 0.08}s` }}
          onClick={() => onViewProfile(user)}
        >
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div className="h-16 w-16 rounded-2xl" style={getAvatarStyle(user.img)} />
            {user.online && (
              <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-card bg-green-500" />
            )}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="font-semibold text-foreground text-sm">
                {user.name}, {user.age}
              </p>
              {user.compatibility && user.compatibility >= 85 && (
                <span className="text-[10px] font-bold text-accent gradient-warm rounded-full px-1.5 py-0.5 text-accent-foreground">
                  {user.compatibility}%
                </span>
              )}
            </div>
            <div className="flex items-center gap-1 text-muted-foreground text-xs mt-0.5">
              <MapPin className="h-3 w-3" /> {user.location}
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-[11px] text-muted-foreground">{user.time}</span>
              {user.crossCount && user.crossCount > 1 && (
                <span className="flex items-center gap-0.5 text-[11px] font-medium text-primary">
                  <Repeat className="h-3 w-3" /> Crossed {user.crossCount}x
                </span>
              )}
            </div>
            {/* Personality tags */}
            <div className="flex gap-1 mt-1.5">
              {user.personalityTags.slice(0, 2).map((tag) => (
                <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded-full bg-secondary text-muted-foreground font-medium">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-1.5" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => onLike(user.id)}
              className="flex h-9 w-9 items-center justify-center rounded-full gradient-warm shadow-card transition-transform hover:scale-110"
            >
              <Heart className={`h-4 w-4 ${likedIds.has(user.id) ? "fill-accent-foreground text-accent-foreground" : "text-accent-foreground"}`} />
            </button>
            <button
              onClick={() => onSuperLike(user.id)}
              className="flex h-9 w-9 items-center justify-center rounded-full gradient-gold shadow-card transition-transform hover:scale-110"
            >
              <Star className="h-4 w-4 text-accent-foreground" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default CrossedTimeline;

import { useState } from "react";
import { Calendar, MapPin, Users, Star, PartyPopper, Coffee, GraduationCap, Handshake, Clock, ChevronRight } from "lucide-react";
import { getAvatarStyle } from "@/data/mockData";

interface ClubEvent {
  id: number;
  title: string;
  type: "party" | "meetup" | "college" | "cafe";
  location: string;
  date: string;
  time: string;
  attendees: number;
  maxAttendees: number;
  attendeeImgs: number[];
  description: string;
  isPremium?: boolean;
}

const MOCK_EVENTS: ClubEvent[] = [
  { id: 1, title: "Rooftop Sunset Party 🌅", type: "party", location: "Sky Lounge, Downtown", date: "Tonight", time: "8:00 PM", attendees: 34, maxAttendees: 50, attendeeImgs: [0, 1, 4, 5], description: "Meet new people over cocktails with a stunning city view" },
  { id: 2, title: "Coffee & Connect ☕", type: "cafe", location: "Brew House, SoHo", date: "Tomorrow", time: "10:00 AM", attendees: 12, maxAttendees: 20, attendeeImgs: [2, 7, 9], description: "Casual morning meetup for coffee lovers" },
  { id: 3, title: "Campus Mixer 🎓", type: "college", location: "NYU Student Center", date: "Fri, Mar 27", time: "6:00 PM", attendees: 56, maxAttendees: 100, attendeeImgs: [3, 6, 8, 11], description: "Connect with students from nearby universities" },
  { id: 4, title: "Fitness & Socialize 💪", type: "meetup", location: "Central Park", date: "Sat, Mar 28", time: "7:00 AM", attendees: 22, maxAttendees: 30, attendeeImgs: [1, 3, 10], description: "Morning workout followed by brunch meetup" },
  { id: 5, title: "Art Gallery Night 🎨", type: "party", location: "Modern Art Space", date: "Sat, Mar 28", time: "7:00 PM", attendees: 18, maxAttendees: 40, attendeeImgs: [4, 9, 12], description: "Exclusive art viewing with wine & conversations", isPremium: true },
];

const TYPE_CONFIG = {
  party: { icon: PartyPopper, label: "Party", color: "gradient-warm" },
  meetup: { icon: Handshake, label: "Meetup", color: "gradient-royal" },
  college: { icon: GraduationCap, label: "College", color: "gradient-gold" },
  cafe: { icon: Coffee, label: "Cafe", color: "bg-green-500" },
};

const ClubScreen = () => {
  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [joinedEvents, setJoinedEvents] = useState<Set<number>>(new Set());

  const filteredEvents = activeFilter === "all" ? MOCK_EVENTS : MOCK_EVENTS.filter((e) => e.type === activeFilter);

  const toggleJoin = (id: number) => {
    setJoinedEvents((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="px-5 pt-3 pb-8">
      {/* Header */}
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-1">
          <Star className="h-5 w-5 text-yellow-500" />
          <h2 className="font-display text-lg font-bold text-foreground">Club</h2>
        </div>
        <p className="text-xs text-muted-foreground">Discover events & meet people nearby</p>
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-4 overflow-x-auto scrollbar-hide pb-1">
        {[
          { key: "all", label: "All Events" },
          { key: "party", label: "🎉 Parties" },
          { key: "cafe", label: "☕ Cafes" },
          { key: "meetup", label: "🤝 Meetups" },
          { key: "college", label: "🎓 College" },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setActiveFilter(f.key)}
            className={`text-xs font-semibold px-3.5 py-2 rounded-full whitespace-nowrap transition-all ${
              activeFilter === f.key
                ? "gradient-royal text-accent-foreground shadow-card"
                : "bg-card text-muted-foreground shadow-card"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Featured event */}
      {filteredEvents[0] && (
        <div className="relative rounded-2xl overflow-hidden mb-4 shadow-elevated">
          <div className="h-44 gradient-royal" />
          <div className="absolute inset-0 flex flex-col justify-end p-4">
            <div className="flex items-center gap-1.5 mb-2">
              <span className="text-xs font-bold text-accent-foreground gradient-warm rounded-full px-2 py-0.5">🔥 HOT</span>
              <span className="text-xs text-accent-foreground/80">{filteredEvents[0].date}</span>
            </div>
            <h3 className="font-display text-xl font-bold text-accent-foreground mb-1">{filteredEvents[0].title}</h3>
            <div className="flex items-center gap-1.5 text-accent-foreground/70 text-xs mb-3">
              <MapPin className="h-3 w-3" /> {filteredEvents[0].location}
            </div>
            <div className="flex items-center justify-between">
              <div className="flex -space-x-2">
                {filteredEvents[0].attendeeImgs.slice(0, 4).map((img, i) => (
                  <div key={i} className="h-7 w-7 rounded-full border-2 border-primary" style={getAvatarStyle(img)} />
                ))}
                <div className="h-7 w-7 rounded-full border-2 border-primary bg-card flex items-center justify-center">
                  <span className="text-[9px] font-bold text-foreground">+{filteredEvents[0].attendees}</span>
                </div>
              </div>
              <button
                onClick={() => toggleJoin(filteredEvents[0].id)}
                className={`text-xs font-bold px-4 py-2 rounded-full transition-all ${
                  joinedEvents.has(filteredEvents[0].id)
                    ? "bg-card text-foreground"
                    : "gradient-warm text-accent-foreground shadow-card"
                }`}
              >
                {joinedEvents.has(filteredEvents[0].id) ? "Joined ✓" : "Join Event"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Event list */}
      <div className="space-y-3">
        {filteredEvents.slice(1).map((event, i) => {
          const config = TYPE_CONFIG[event.type];
          const Icon = config.icon;
          const isJoined = joinedEvents.has(event.id);

          return (
            <div
              key={event.id}
              className="flex gap-3 rounded-2xl bg-card shadow-card p-3.5 animate-fade-up relative"
              style={{ animationDelay: `${i * 0.06}s` }}
            >
              {event.isPremium && (
                <div className="absolute top-2 right-2 gradient-gold rounded-full px-2 py-0.5">
                  <span className="text-[9px] font-bold text-accent-foreground">💎 VIP</span>
                </div>
              )}
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${config.color} flex-shrink-0`}>
                <Icon className="h-6 w-6 text-accent-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-semibold text-foreground mb-0.5">{event.title}</h4>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
                  <MapPin className="h-3 w-3" /> {event.location}
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                  <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {event.date}</span>
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {event.time}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="flex -space-x-1.5">
                      {event.attendeeImgs.slice(0, 3).map((img, j) => (
                        <div key={j} className="h-5 w-5 rounded-full border border-card" style={getAvatarStyle(img)} />
                      ))}
                    </div>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                      <Users className="h-3 w-3" /> {event.attendees}/{event.maxAttendees}
                    </span>
                  </div>
                  <button
                    onClick={() => toggleJoin(event.id)}
                    className={`text-[11px] font-semibold px-3 py-1.5 rounded-full transition-all ${
                      isJoined
                        ? "bg-secondary text-secondary-foreground"
                        : "gradient-royal text-accent-foreground"
                    }`}
                  >
                    {isJoined ? "Joined ✓" : "Join"}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ClubScreen;

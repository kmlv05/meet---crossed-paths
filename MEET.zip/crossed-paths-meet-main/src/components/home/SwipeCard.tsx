import { useState, useRef } from "react";
import { Heart, X, Star, MapPin, Briefcase, Music, Sparkles } from "lucide-react";
import { getAvatarStyle, type MockUser } from "@/data/mockData";

interface SwipeCardProps {
  user: MockUser;
  onLike: () => void;
  onPass: () => void;
  onSuperLike: () => void;
  onViewProfile: () => void;
  isTop: boolean;
}

const SwipeCard = ({ user, onLike, onPass, onSuperLike, onViewProfile, isTop }: SwipeCardProps) => {
  const [dragX, setDragX] = useState(0);
  const [dragY, setDragY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [isExiting, setIsExiting] = useState<"left" | "right" | "up" | null>(null);
  const startPos = useRef({ x: 0, y: 0 });

  const threshold = 100;
  const superLikeThreshold = -80;

  const handleStart = (clientX: number, clientY: number) => {
    if (!isTop) return;
    setIsDragging(true);
    startPos.current = { x: clientX, y: clientY };
  };

  const handleMove = (clientX: number, clientY: number) => {
    if (!isDragging) return;
    setDragX(clientX - startPos.current.x);
    setDragY(clientY - startPos.current.y);
  };

  const handleEnd = () => {
    if (!isDragging) return;
    setIsDragging(false);

    if (dragX > threshold) {
      exitCard("right");
    } else if (dragX < -threshold) {
      exitCard("left");
    } else if (dragY < superLikeThreshold) {
      exitCard("up");
    } else {
      setDragX(0);
      setDragY(0);
    }
  };

  const exitCard = (direction: "left" | "right" | "up") => {
    setIsExiting(direction);
    setTimeout(() => {
      if (direction === "right") onLike();
      else if (direction === "left") onPass();
      else onSuperLike();
    }, 300);
  };

  const rotation = isDragging ? dragX * 0.08 : 0;
  const opacity = isDragging ? Math.max(0.6, 1 - Math.abs(dragX) / 400) : 1;

  const getExitTransform = () => {
    if (isExiting === "left") return "translateX(-150%) rotate(-30deg)";
    if (isExiting === "right") return "translateX(150%) rotate(30deg)";
    if (isExiting === "up") return "translateY(-150%) scale(0.8)";
    return `translateX(${dragX}px) translateY(${dragY}px) rotate(${rotation}deg)`;
  };

  return (
    <div
      className={`absolute inset-y-0 left-0 right-0 mx-auto w-full max-w-[400px] aspect-[9/16] max-h-[100%] ${isExiting ? "transition-transform duration-300 ease-out" : isDragging ? "" : "transition-transform duration-200"}`}
      style={{
        transform: getExitTransform(),
        opacity: isExiting ? 0 : opacity,
        zIndex: isTop ? 10 : 5,
        touchAction: "none",
      }}
      onMouseDown={(e) => handleStart(e.clientX, e.clientY)}
      onMouseMove={(e) => handleMove(e.clientX, e.clientY)}
      onMouseUp={handleEnd}
      onMouseLeave={() => isDragging && handleEnd()}
      onTouchStart={(e) => handleStart(e.touches[0].clientX, e.touches[0].clientY)}
      onTouchMove={(e) => handleMove(e.touches[0].clientX, e.touches[0].clientY)}
      onTouchEnd={handleEnd}
    >
      <div className="h-full w-full sm:h-[calc(100%-2rem)] sm:my-4 rounded-3xl overflow-hidden shadow-elevated bg-card relative cursor-grab active:cursor-grabbing select-none">
        {/* Photo */}
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={user.realImageUrls && user.realImageUrls.length > 0 ? { backgroundImage: `url(${user.realImageUrls[0]})` } : getAvatarStyle(user.img)} 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/90 via-foreground/30 to-transparent pointer-events-none" />

        {/* Swipe indicators */}
        {isDragging && dragX > 40 && (
          <div className="absolute top-16 left-6 z-20 border-4 border-green-500 rounded-2xl px-5 py-2 rotate-[-15deg] animate-bounce-in">
            <span className="text-green-500 font-bold text-3xl">LIKE</span>
          </div>
        )}
        {isDragging && dragX < -40 && (
          <div className="absolute top-16 right-6 z-20 border-4 border-accent rounded-2xl px-5 py-2 rotate-[15deg] animate-bounce-in">
            <span className="text-accent font-bold text-3xl">NOPE</span>
          </div>
        )}
        {isDragging && dragY < -40 && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 border-4 border-yellow-400 rounded-2xl px-5 py-2 animate-bounce-in">
            <span className="text-yellow-400 font-bold text-3xl">SUPER</span>
          </div>
        )}

        {/* Online & compatibility badges */}
        <div className="absolute top-5 left-5 flex items-center gap-2 z-10">
          {user.online && (
            <div className="flex items-center gap-1.5 glass rounded-full px-3 py-1.5">
              <span className="h-2 w-2 rounded-full bg-green-500 animate-ping-slow" />
              <span className="text-xs font-medium text-foreground">Online</span>
            </div>
          )}
          {user.compatibility && user.compatibility >= 80 && (
            <div className="flex items-center gap-1 gradient-warm rounded-full px-3 py-1.5">
              <Sparkles className="h-3 w-3 text-accent-foreground" />
              <span className="text-xs font-bold text-accent-foreground">{user.compatibility}%</span>
            </div>
          )}
        </div>

        {/* User info at bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-5 z-10" onClick={onViewProfile}>
          <h2 className="font-display text-3xl font-bold text-accent-foreground mb-1">
            {user.name}, {user.age}
          </h2>
          {user.job && (
            <div className="flex items-center gap-1.5 text-accent-foreground/80 text-sm mb-1">
              <Briefcase className="h-3.5 w-3.5" /> {user.job}
            </div>
          )}
          <div className="flex items-center gap-1.5 text-accent-foreground/70 text-sm mb-3">
            <MapPin className="h-3.5 w-3.5" /> {user.distance || "Nearby"}
          </div>
          {user.interests.length > 0 && (
            <div className="flex gap-1.5 flex-wrap">
              {user.interests.slice(0, 3).map((tag) => (
                <span key={tag} className="text-xs px-2.5 py-1 rounded-full glass text-accent-foreground font-medium">
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div className="absolute bottom-5 right-5 flex items-center gap-2.5 z-20" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => exitCard("left")}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-card/90 backdrop-blur-sm shadow-elevated transition-transform hover:scale-110 active:scale-95"
          >
            <X className="h-6 w-6 text-accent" />
          </button>
          <button
            onClick={() => exitCard("up")}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-card/90 backdrop-blur-sm shadow-elevated transition-transform hover:scale-110 active:scale-95"
          >
            <Star className="h-5 w-5 text-yellow-500" />
          </button>
          <button
            onClick={() => exitCard("right")}
            className="flex h-12 w-12 items-center justify-center rounded-full gradient-warm shadow-elevated transition-transform hover:scale-110 active:scale-95"
          >
            <Heart className="h-6 w-6 text-accent-foreground" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default SwipeCard;

import { Heart, MapPin, Sparkles, Star } from "lucide-react";
import { getAvatarStyle, type MockUser } from "@/data/mockData";

interface NearbyGridProps {
  users: MockUser[];
  likedIds: Set<number>;
  superLikedId: number | null;
  onLike: (id: number) => void;
  onSuperLike: (id: number) => void;
  onViewProfile: (user: MockUser) => void;
}

const NearbyGrid = ({ users, likedIds, superLikedId, onLike, onSuperLike, onViewProfile }: NearbyGridProps) => {
  return (
    <div className="px-5 pt-3">
      {/* Compatibility highlights */}
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="h-4 w-4 text-accent" />
          <span className="text-sm font-semibold text-foreground">Top Compatibility</span>
        </div>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
          {users
            .filter((u) => (u.compatibility || 0) >= 85)
            .map((user) => (
              <button
                key={user.id}
                onClick={() => onViewProfile(user)}
                className="flex flex-col items-center gap-1.5 flex-shrink-0"
              >
                <div className="relative">
                  <div className="h-16 w-16 rounded-full gradient-warm p-[2px]">
                    <div className="h-full w-full rounded-full" style={getAvatarStyle(user.img)} />
                  </div>
                  {user.online && (
                    <span className="absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full border-2 border-background bg-green-500" />
                  )}
                </div>
                <span className="text-[11px] font-medium text-foreground">{user.name}</span>
                <span className="text-[10px] font-semibold text-accent">{user.compatibility}%</span>
              </button>
            ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 gap-3">
        {users.map((user, i) => (
          <div
            key={user.id}
            className="relative rounded-2xl overflow-hidden shadow-card bg-card animate-fade-up cursor-pointer group"
            style={{ animationDelay: `${i * 0.06}s` }}
            onClick={() => onViewProfile(user)}
          >
            <div className="aspect-[3/4] w-full" style={getAvatarStyle(user.img)} />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/10 to-transparent" />

            {/* Online indicator */}
            {user.online && (
              <div className="absolute top-3 left-3 flex items-center gap-1 glass rounded-full px-2 py-1">
                <span className="h-2 w-2 rounded-full bg-green-500 animate-ping-slow" />
                <span className="text-[10px] font-medium text-foreground">Online</span>
              </div>
            )}

            {/* Compatibility badge */}
            {user.compatibility && user.compatibility >= 80 && (
              <div className="absolute top-3 right-12 gradient-warm rounded-full px-2 py-0.5">
                <span className="text-[10px] font-bold text-accent-foreground">{user.compatibility}%</span>
              </div>
            )}

            {/* Super like animation */}
            {superLikedId === user.id && (
              <div className="absolute inset-0 flex items-center justify-center z-10">
                <Star className="h-20 w-20 text-yellow-400 fill-yellow-400 animate-super-like" />
              </div>
            )}

            {/* Info */}
            <div className="absolute bottom-0 left-0 right-0 p-3">
              <p className="font-semibold text-accent-foreground text-sm">
                {user.name}, {user.age}
              </p>
              <div className="flex items-center gap-1 text-accent-foreground/80 text-xs">
                <MapPin className="h-3 w-3" /> {user.distance}
              </div>
              {user.interests.length > 0 && (
                <div className="flex gap-1 mt-1.5 flex-wrap">
                  {user.interests.slice(0, 2).map((tag) => (
                    <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded-full glass text-accent-foreground font-medium">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="absolute top-3 right-3 flex flex-col gap-1.5" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={() => onLike(user.id)}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-card/80 backdrop-blur-sm shadow-card transition-transform hover:scale-110"
              >
                <Heart className={`h-4 w-4 transition-colors ${likedIds.has(user.id) ? "text-accent fill-accent" : "text-muted-foreground"}`} />
              </button>
              <button
                onClick={() => onSuperLike(user.id)}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-card/80 backdrop-blur-sm shadow-card transition-transform hover:scale-110"
              >
                <Star className="h-4 w-4 text-yellow-500" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NearbyGrid;

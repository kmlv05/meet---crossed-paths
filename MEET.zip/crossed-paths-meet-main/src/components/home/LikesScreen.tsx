import { Heart, Lock, Eye } from "lucide-react";
import { getAvatarStyle, type MockUser } from "@/data/mockData";

interface LikesScreenProps {
  likedIds: Set<number>;
  allUsers: MockUser[];
  onViewProfile: (user: MockUser) => void;
  onShowPremium: () => void;
}

const LikesScreen = ({ likedIds, allUsers, onViewProfile, onShowPremium }: LikesScreenProps) => {
  const likedUsers = allUsers.filter((u) => likedIds.has(u.id));

  return (
    <div className="px-5 pt-3">
      {/* Secret admirers (blurred - premium) */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Secret Admirers</h3>
          <button onClick={onShowPremium} className="text-xs font-medium text-accent flex items-center gap-1">
            <Lock className="h-3 w-3" /> Unlock
          </button>
        </div>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
          {[16, 17, 18, 19].map((imgIdx) => (
            <button
              key={imgIdx}
              onClick={onShowPremium}
              className="relative flex-shrink-0"
            >
              <div className="h-20 w-20 rounded-2xl overflow-hidden blur-md" style={getAvatarStyle(imgIdx)} />
              <div className="absolute inset-0 flex items-center justify-center">
                <Eye className="h-5 w-5 text-primary" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Your likes */}
      <h3 className="text-sm font-semibold text-foreground mb-3">
        People You Liked ({likedUsers.length})
      </h3>
      {likedUsers.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Heart className="h-12 w-12 text-muted-foreground mb-3" />
          <p className="text-sm text-muted-foreground">No likes yet</p>
          <p className="text-xs text-muted-foreground mt-1">Start exploring to find your match!</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {likedUsers.map((user, i) => (
            <button
              key={user.id}
              onClick={() => onViewProfile(user)}
              className="relative rounded-xl overflow-hidden shadow-card animate-fade-up"
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <div className="aspect-square w-full" style={getAvatarStyle(user.img)} />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-1.5">
                <p className="text-[11px] font-semibold text-accent-foreground">{user.name}, {user.age}</p>
              </div>
              <Heart className="absolute top-1.5 right-1.5 h-3.5 w-3.5 text-accent fill-accent" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LikesScreen;

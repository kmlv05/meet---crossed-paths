import { MapPin, Clock } from "lucide-react";
import { getAvatarStyle, type MockUser } from "@/data/mockData";

interface MapViewProps {
  users: MockUser[];
  onViewProfile: (user: MockUser) => void;
}

const ENCOUNTER_SPOTS = [
  { x: 25, y: 30, label: "Central Park" },
  { x: 60, y: 45, label: "Broadway Café" },
  { x: 40, y: 65, label: "Union Square" },
  { x: 75, y: 25, label: "5th Avenue" },
  { x: 15, y: 55, label: "SoHo Gallery" },
];

const MapView = ({ users, onViewProfile }: MapViewProps) => {
  return (
    <div className="px-5 pt-3">
      {/* Filter chips */}
      <div className="flex gap-2 mb-4 overflow-x-auto scrollbar-hide">
        {["Today", "This Week", "This Month"].map((filter, i) => (
          <button
            key={filter}
            className={`flex-shrink-0 rounded-full px-4 py-1.5 text-xs font-semibold transition-all ${
              i === 0 ? "gradient-royal text-accent-foreground" : "bg-card shadow-card text-muted-foreground"
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Map placeholder */}
      <div className="relative rounded-2xl bg-secondary overflow-hidden shadow-elevated" style={{ height: "55vh" }}>
        {/* Grid pattern for map feel */}
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "linear-gradient(hsl(var(--primary)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--primary)) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }} />

        {/* Street lines */}
        <div className="absolute top-1/2 left-0 right-0 h-[2px] bg-primary/10" />
        <div className="absolute left-1/2 top-0 bottom-0 w-[2px] bg-primary/10" />
        <div className="absolute top-1/4 left-0 right-0 h-[1px] bg-primary/5" />
        <div className="absolute top-3/4 left-0 right-0 h-[1px] bg-primary/5" />
        <div className="absolute left-1/4 top-0 bottom-0 w-[1px] bg-primary/5" />
        <div className="absolute left-3/4 top-0 bottom-0 w-[1px] bg-primary/5" />

        {/* Encounter pins */}
        {users.slice(0, 5).map((user, i) => {
          const spot = ENCOUNTER_SPOTS[i];
          return (
            <button
              key={user.id}
              onClick={() => onViewProfile(user)}
              className="absolute group animate-bounce-in"
              style={{
                left: `${spot.x}%`,
                top: `${spot.y}%`,
                transform: "translate(-50%, -50%)",
                animationDelay: `${i * 0.15}s`,
              }}
            >
              {/* Ping effect */}
              <span className="absolute inset-0 rounded-full gradient-warm opacity-30 animate-ping-slow" />

              {/* Avatar pin */}
              <div className="relative">
                <div className="h-12 w-12 rounded-full gradient-warm p-[2px] shadow-elevated">
                  <div className="h-full w-full rounded-full" style={getAvatarStyle(user.img)} />
                </div>
                {user.crossCount && user.crossCount > 1 && (
                  <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full gradient-royal text-[9px] font-bold text-accent-foreground shadow-card">
                    {user.crossCount}x
                  </span>
                )}
              </div>

              {/* Tooltip */}
              <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 glass rounded-lg px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-card">
                <p className="text-[10px] font-semibold text-foreground">{user.name}</p>
                <p className="text-[9px] text-muted-foreground">{spot.label}</p>
              </div>
            </button>
          );
        })}

        {/* Legend */}
        <div className="absolute bottom-3 left-3 glass rounded-xl px-3 py-2">
          <div className="flex items-center gap-2">
            <MapPin className="h-3.5 w-3.5 text-accent" />
            <span className="text-[11px] font-medium text-foreground">{users.length} encounters today</span>
          </div>
        </div>

        {/* Heatmap zone indicator */}
        <div className="absolute top-4 right-4 glass rounded-xl px-3 py-2">
          <div className="flex items-center gap-1.5">
            <div className="h-2.5 w-2.5 rounded-full gradient-warm" />
            <span className="text-[10px] font-medium text-foreground">Hotspot zone</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapView;

import { useState, useEffect } from "react";
import { Camera, Edit3, MapPin, Music, Briefcase, Settings, Heart, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/api";
import SettingsScreen from "./SettingsScreen";
import { auth } from "@/lib/firebase";

const ProfileScreen = () => {
  const [showSettings, setShowSettings] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ name: "", age: "", bio: "" });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await api.get("/api/users/profile");
        setProfile(res.data);
        setEditForm({
          name: res.data.name || "",
          age: res.data.age || "",
          bio: res.data.bio || ""
        });
      } catch (error) {
        console.error("Failed to fetch custom profile details", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchProfile();
  }, []);

  const saveProfile = async () => {
    try {
      const updatedProfile = { 
        ...profile, 
        name: editForm.name, 
        age: parseInt(editForm.age as string) || 21, 
        bio: editForm.bio 
      };
      await api.post("/api/users/profile", updatedProfile);
      setProfile(updatedProfile);
      setEditing(false);
      toast.success("Profile basic details updated successfully!");
    } catch (e: any) {
      toast.error("Failed to update profile");
    }
  };

  if (showSettings) {
    return <SettingsScreen onBack={() => setShowSettings(false)} />;
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center p-12">
        <Loader2 className="h-8 w-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex h-full flex-col items-center justify-center p-12 text-center">
        <p className="text-muted-foreground">Profile not found. Please log in again.</p>
        <button onClick={() => auth.signOut()} className="mt-4 text-primary font-semibold">Sign Out</button>
      </div>
    );
  }

  const primaryImageUrl = profile.imageUrls && profile.imageUrls.length > 0 
    ? profile.imageUrls[0] 
    : "";

  return (
    <div className="px-5 pt-3 pb-8 h-full overflow-y-auto">
      {/* Profile header */}
      <div className="flex flex-col items-center mb-6">
        <div className="relative mb-3">
          <div className="h-28 w-28 rounded-full gradient-warm p-[3px] shadow-xl">
            <div 
              className="h-full w-full rounded-full bg-muted bg-cover bg-center" 
              style={{ backgroundImage: primaryImageUrl ? `url(${primaryImageUrl})` : "none" }} 
            />
          </div>
        </div>
        
        {editing ? (
          <div className="w-full space-y-3 mt-4 px-4 bg-card shadow-card rounded-2xl p-4 border border-border">
             <input
               value={editForm.name}
               onChange={(e) => setEditForm({...editForm, name: e.target.value})}
               placeholder="Your name"
               className="w-full text-center h-10 rounded-lg bg-background border border-border text-sm font-bold placeholder:font-normal focus:ring-2 focus:ring-primary/20 outline-none"
             />
             <input
               type="number"
               value={editForm.age}
               onChange={(e) => setEditForm({...editForm, age: e.target.value})}
               placeholder="Age"
               className="w-full text-center h-10 rounded-lg bg-background border border-border text-sm font-bold placeholder:font-normal focus:ring-2 focus:ring-primary/20 outline-none"
             />
             <textarea
               value={editForm.bio}
               onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
               placeholder="Write a bio"
               className="w-full h-20 p-3 rounded-lg bg-background border border-border text-xs resize-none focus:ring-2 focus:ring-primary/20 outline-none"
             />
             <div className="flex gap-2 justify-center">
               <button onClick={() => setEditing(false)} className="flex-1 rounded-xl bg-secondary py-2 text-xs font-bold text-foreground hover:opacity-80">Cancel</button>
               <button onClick={saveProfile} className="flex-1 rounded-xl gradient-royal py-2 text-xs font-bold text-accent-foreground shadow-sm hover:opacity-90">Save</button>
             </div>
          </div>
        ) : (
          <>
            <h2 className="font-display text-xl font-bold text-foreground">
              {profile.name || "Anonymous"}, {profile.age || 21}
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5 px-4 text-center">
              {profile.bio || "No bio added yet."}
            </p>
            <button onClick={() => setEditing(true)} className="mt-4 flex items-center gap-1.5 rounded-full bg-card shadow-card px-5 py-2.5 text-xs font-bold text-primary hover:bg-secondary transition-colors">
              <Edit3 className="h-3.5 w-3.5" /> Edit Profile
            </button>
          </>
        )}
      </div>

      {/* Stats - using mocked stats for aesthetics since we didn't add stats to backend model yet */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: "Likes", value: 12, icon: Heart },
          { label: "Matches", value: 4, icon: Heart },
          { label: "Crossed", value: 24, icon: MapPin },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl bg-card shadow-card p-3 text-center">
            <stat.icon className="h-4 w-4 text-accent mx-auto mb-1" />
            <p className="text-lg font-bold text-foreground">{stat.value}</p>
            <p className="text-[10px] text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Info */}
      <div className="space-y-5">
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Interests</h4>
          <div className="flex flex-wrap gap-2">
            {profile.interests && profile.interests.length > 0 ? (
              profile.interests.map((tag: string) => (
                <span key={tag} className="text-xs px-3 py-1.5 rounded-full gradient-warm shadow-sm text-foreground font-medium">
                  {tag}
                </span>
              ))
            ) : (
              <span className="text-xs text-muted-foreground">No interests selected.</span>
            )}
          </div>
        </div>
        
        {profile.gender && profile.gender !== "Not Specified" && (
          <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Gender</h4>
            <div className="flex flex-wrap gap-2">
              <span className="text-xs px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground font-medium">
                {profile.gender}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Settings button */}
      <div className="mt-8">
        <button
          onClick={() => setShowSettings(true)}
          className="flex items-center gap-3 w-full rounded-xl p-3 hover:bg-card transition-colors shadow-sm bg-card/50"
        >
          <Settings className="h-5 w-5 text-muted-foreground" />
          <span className="text-sm font-semibold text-foreground">Settings</span>
        </button>
      </div>
    </div>
  );
};

export default ProfileScreen;

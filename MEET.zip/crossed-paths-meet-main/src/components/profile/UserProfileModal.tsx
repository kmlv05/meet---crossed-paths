import { Heart, Star, X, MessageCircle, MapPin, Music, Briefcase, Sparkles, AlertTriangle } from "lucide-react";
import { getAvatarStyle, type MockUser } from "@/data/mockData";

interface UserProfileModalProps {
  user: MockUser;
  isLiked: boolean;
  onClose: () => void;
  onLike: () => void;
  onSuperLike: () => void;
  onMessage: () => void;
}

const UserProfileModal = ({ user, isLiked, onClose, onLike, onSuperLike, onMessage }: UserProfileModalProps) => {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm animate-fade-up" onClick={onClose}>
      <div
        className="w-full max-w-lg bg-background rounded-t-3xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Profile photo */}
        <div className="relative">
          <div className="aspect-[4/5] w-full rounded-t-3xl" style={getAvatarStyle(user.img)} />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

          {/* Close */}
          <button onClick={onClose} className="absolute top-4 right-4 flex h-9 w-9 items-center justify-center rounded-full glass shadow-card">
            <X className="h-5 w-5 text-foreground" />
          </button>

          {/* Report User */}
          <button 
             onClick={async () => {
               if (window.confirm("Are you sure you want to report this user for violating community guidelines?")) {
                 try {
                   const { api } = await import("@/lib/api");
                   const { toast } = await import("sonner");
                   await api.post(`/api/users/report/${user.id}`, "Inappropriate content");
                   toast.success("User reported. Our moderation team will review this profile.");
                   onClose();
                 } catch (e) {}
               }
             }}
             className="absolute top-4 right-16 flex h-9 w-9 items-center justify-center rounded-full glass shadow-card border border-destructive/20"
             title="Report Inappropriate Content"
          >
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </button>

          {/* Compatibility */}
          {user.compatibility && (
            <div className="absolute top-4 left-4 gradient-warm rounded-full px-3 py-1.5 shadow-card flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-accent-foreground" />
              <span className="text-xs font-bold text-accent-foreground">{user.compatibility}% Match</span>
            </div>
          )}

          {/* Name overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-5">
            <h2 className="font-display text-3xl font-bold text-foreground">
              {user.name}, {user.age}
            </h2>
            {user.distance && (
              <div className="flex items-center gap-1 text-muted-foreground text-sm mt-1">
                <MapPin className="h-4 w-4" /> {user.distance} away
              </div>
            )}
            {user.location && (
              <div className="flex items-center gap-1 text-muted-foreground text-sm mt-1">
                <MapPin className="h-4 w-4" /> Last seen at {user.location}
              </div>
            )}
          </div>
        </div>

        {/* Details */}
        <div className="px-5 py-4 space-y-5">
          {/* Bio */}
          <p className="text-sm text-foreground leading-relaxed">{user.bio}</p>

          {/* Job & Music */}
          <div className="flex flex-wrap gap-3">
            {user.job && (
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Briefcase className="h-4 w-4" /> {user.job}
              </div>
            )}
            {user.music && (
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Music className="h-4 w-4" /> {user.music}
              </div>
            )}
          </div>

          {/* Interests */}
          <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Interests</h4>
            <div className="flex flex-wrap gap-2">
              {user.interests.map((tag) => (
                <span key={tag} className="text-xs px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground font-medium">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Personality */}
          <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Personality</h4>
            <div className="flex flex-wrap gap-2">
              {user.personalityTags.map((tag) => (
                <span key={tag} className="text-xs px-3 py-1.5 rounded-full gradient-royal text-accent-foreground font-medium">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Cross paths info */}
          {user.crossCount && user.crossCount > 1 && (
            <div className="flex items-center gap-2 rounded-xl bg-card p-3 shadow-card">
              <MapPin className="h-5 w-5 text-accent" />
              <div>
                <p className="text-xs font-semibold text-foreground">Crossed paths {user.crossCount} times</p>
                <p className="text-[10px] text-muted-foreground">Maybe it's a sign? 😉</p>
              </div>
            </div>
          )}
        </div>

        {/* Action bar */}
        <div className="sticky bottom-0 bg-background border-t border-border px-5 py-4">
          <div className="flex items-center justify-center gap-4">
            <button onClick={onClose} className="flex h-14 w-14 items-center justify-center rounded-full bg-card shadow-card transition-transform hover:scale-110">
              <X className="h-6 w-6 text-muted-foreground" />
            </button>
            <button onClick={onSuperLike} className="flex h-14 w-14 items-center justify-center rounded-full gradient-gold shadow-elevated transition-transform hover:scale-110">
              <Star className="h-7 w-7 text-accent-foreground" />
            </button>
            <button onClick={onLike} className="flex h-16 w-16 items-center justify-center rounded-full gradient-warm shadow-elevated transition-transform hover:scale-110">
              <Heart className={`h-8 w-8 ${isLiked ? "fill-accent-foreground text-accent-foreground" : "text-accent-foreground"}`} />
            </button>
            <button onClick={onMessage} className="flex h-14 w-14 items-center justify-center rounded-full gradient-royal shadow-elevated transition-transform hover:scale-110">
              <MessageCircle className="h-6 w-6 text-accent-foreground" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfileModal;

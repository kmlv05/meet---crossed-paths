import { useState } from "react";
import { ArrowLeft, User, Lock, Bell, Shield, FileText, ChevronRight, Eye, EyeOff, MapPin, AlertTriangle, Moon, Sun, LogOut } from "lucide-react";
import { auth } from "@/lib/firebase";
import { toast } from "sonner";

interface SettingsScreenProps {
  onBack: () => void;
}

type SettingsSection = "main" | "account" | "privacy" | "notifications" | "policy" | "terms" | "guidelines";

const SettingsScreen = ({ onBack }: SettingsScreenProps) => {
  const [section, setSection] = useState<SettingsSection>("main");
  const [ghostMode, setGhostMode] = useState(false);
  const [approxLocation, setApproxLocation] = useState(true);
  const [notifMatches, setNotifMatches] = useState(true);
  const [notifMessages, setNotifMessages] = useState(true);
  const [notifCrossed, setNotifCrossed] = useState(true);
  const [notifEvents, setNotifEvents] = useState(true);
  const [darkMode, setDarkMode] = useState(() => document.documentElement.classList.contains("dark"));

  const toggleDark = () => {
    const next = !darkMode;
    setDarkMode(next);
    document.documentElement.classList.toggle("dark", next);
  };

  const Toggle = ({ on, onToggle }: { on: boolean; onToggle: () => void }) => (
    <button onClick={onToggle} className={`relative w-11 h-6 rounded-full transition-all ${on ? "gradient-royal" : "bg-secondary"}`}>
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-card shadow-card transition-transform ${on ? "translate-x-5" : "translate-x-0.5"}`} />
    </button>
  );

  if (section === "policy") {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3 flex items-center gap-3">
          <button onClick={() => setSection("main")} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
            <ArrowLeft className="h-5 w-5 text-primary" />
          </button>
          <h1 className="font-display text-lg font-bold text-foreground">Privacy Policy</h1>
        </header>
        <div className="px-5 py-4 text-sm text-muted-foreground space-y-4 leading-relaxed">
          <p className="text-foreground font-semibold">Last updated: March 2026</p>
          <p>Meet ❤️ ("we", "our") respects your privacy. This policy explains how we collect, use, and protect your personal information.</p>
          <h3 className="text-foreground font-semibold">1. Information We Collect</h3>
          <p>We collect information you provide (name, photos, bio, interests) and usage data including approximate location. We never share your exact GPS coordinates with other users.</p>
          <h3 className="text-foreground font-semibold">2. Location Data</h3>
          <p>We use location data to power the "Crossed Paths" feature. Only approximate locations (~250m radius) are shown to other users. You can disable location sharing via Ghost Mode at any time.</p>
          <h3 className="text-foreground font-semibold">3. Data Security</h3>
          <p>All chats are end-to-end encrypted. We employ industry-standard security measures to protect your data. Screenshot alerts notify users when someone captures their chat.</p>
          <h3 className="text-foreground font-semibold">4. Your Rights</h3>
          <p>You may request deletion of your data at any time through Account Settings. You can control visibility, block users, and manage notification preferences.</p>
          <h3 className="text-foreground font-semibold">5. Contact</h3>
          <p>For questions about this policy, contact us at privacy@meetapp.com</p>
        </div>
      </div>
    );
  }

  if (section === "terms") {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3 flex items-center gap-3">
          <button onClick={() => setSection("main")} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
            <ArrowLeft className="h-5 w-5 text-primary" />
          </button>
          <h1 className="font-display text-lg font-bold text-foreground">Terms & Conditions</h1>
        </header>
        <div className="px-5 py-4 text-sm text-muted-foreground space-y-4 leading-relaxed">
          <p className="text-foreground font-semibold">Effective: March 2026</p>
          <h3 className="text-foreground font-semibold">1. Eligibility</h3>
          <p>You must be at least 16 years old to use Meet ❤️. By creating an account, you confirm you meet this requirement.</p>
          <h3 className="text-foreground font-semibold">2. User Conduct</h3>
          <p>You agree to use the app respectfully. Harassment, spam, impersonation, and sharing explicit content without consent are prohibited.</p>
          <h3 className="text-foreground font-semibold">3. Premium Features</h3>
          <p>Premium subscriptions are billed at ₹30/month. You can cancel anytime. Refunds follow applicable app store policies.</p>
          <h3 className="text-foreground font-semibold">4. Content Ownership</h3>
          <p>You retain ownership of your content. By posting, you grant us a non-exclusive license to display it within the app.</p>
          <h3 className="text-foreground font-semibold">5. Limitation of Liability</h3>
          <p>Meet ❤️ is provided "as is". We are not liable for interactions between users. Always exercise caution when meeting people.</p>
        </div>
      </div>
    );
  }

  if (section === "guidelines") {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3 flex items-center gap-3">
          <button onClick={() => setSection("main")} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
            <ArrowLeft className="h-5 w-5 text-primary" />
          </button>
          <h1 className="font-display text-lg font-bold text-foreground">Community Guidelines</h1>
        </header>
        <div className="px-5 py-4 text-sm text-muted-foreground space-y-4 leading-relaxed">
          <p className="text-foreground font-semibold">Be kind. Be real. Be safe.</p>
          <h3 className="text-foreground font-semibold">✅ Do</h3>
          <ul className="list-disc pl-4 space-y-1">
            <li>Be authentic — use real photos and honest information</li>
            <li>Treat others with respect and kindness</li>
            <li>Report suspicious or harmful behavior</li>
            <li>Meet in public places for first dates</li>
          </ul>
          <h3 className="text-foreground font-semibold">❌ Don't</h3>
          <ul className="list-disc pl-4 space-y-1">
            <li>Harass, bully, or intimidate other users</li>
            <li>Share explicit content without consent</li>
            <li>Create fake profiles or impersonate others</li>
            <li>Spam or promote commercial content</li>
            <li>Share others' private information</li>
          </ul>
          <h3 className="text-foreground font-semibold">⚠️ Violations</h3>
          <p>Violations may result in warnings, temporary suspensions, or permanent bans. We take safety seriously.</p>
        </div>
      </div>
    );
  }

  if (section === "privacy") {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3 flex items-center gap-3">
          <button onClick={() => setSection("main")} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
            <ArrowLeft className="h-5 w-5 text-primary" />
          </button>
          <h1 className="font-display text-lg font-bold text-foreground">Privacy & Safety</h1>
        </header>
        <div className="px-5 py-4 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <EyeOff className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium text-foreground">Ghost Mode</p>
                <p className="text-[10px] text-muted-foreground">Hide from other users</p>
              </div>
            </div>
            <Toggle on={ghostMode} onToggle={() => setGhostMode(!ghostMode)} />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MapPin className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium text-foreground">Approximate Location</p>
                <p className="text-[10px] text-muted-foreground">Only show ~250m radius</p>
              </div>
            </div>
            <Toggle on={approxLocation} onToggle={() => setApproxLocation(!approxLocation)} />
          </div>
          <div className="rounded-2xl bg-card shadow-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="h-4 w-4 text-accent" />
              <span className="text-xs font-semibold text-foreground">End-to-End Encryption</span>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              All chats are end-to-end encrypted. Screenshot alerts are enabled by default to protect your conversations.
            </p>
          </div>
          <div className="space-y-2">
            <button className="w-full flex items-center gap-3 rounded-xl p-3 hover:bg-card transition-colors">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              <span className="text-sm text-foreground">Block & Report Users</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (section === "notifications") {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3 flex items-center gap-3">
          <button onClick={() => setSection("main")} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
            <ArrowLeft className="h-5 w-5 text-primary" />
          </button>
          <h1 className="font-display text-lg font-bold text-foreground">Notifications</h1>
        </header>
        <div className="px-5 py-4 space-y-5">
          {[
            { label: "Matches", on: notifMatches, toggle: () => setNotifMatches(!notifMatches) },
            { label: "Messages", on: notifMessages, toggle: () => setNotifMessages(!notifMessages) },
            { label: "Crossed Paths", on: notifCrossed, toggle: () => setNotifCrossed(!notifCrossed) },
            { label: "Event Invites", on: notifEvents, toggle: () => setNotifEvents(!notifEvents) },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">{item.label}</span>
              <Toggle on={item.on} onToggle={item.toggle} />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (section === "account") {
    const user = auth.currentUser;

    const handleChangePassword = async () => {
      if (!user?.email) return toast.error("No email attached to this account.");
      try {
        const { sendPasswordResetEmail } = await import("firebase/auth");
        await sendPasswordResetEmail(auth, user.email);
        toast.success("Password reset email sent! Check your inbox.");
      } catch (e: any) {
        toast.error("Error: " + e.message);
      }
    };

    const handleDeleteAccount = async () => {
      if (window.confirm("Are you sure you want to permanently delete your account? This action cannot be undone.")) {
        try {
          if (user) {
            const { deleteUser } = await import("firebase/auth");
            await deleteUser(user);
            toast.success("Account deleted successfully.");
          }
        } catch (e: any) {
          if (e.code === "auth/requires-recent-login") {
            toast.error("Please sign out and back in to verify your identity before deleting your account.");
          } else {
            toast.error("Error deleting account: " + e.message);
          }
        }
      }
    };

    return (
      <div className="flex min-h-screen flex-col bg-background">
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3 flex items-center gap-3">
          <button onClick={() => setSection("main")} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
            <ArrowLeft className="h-5 w-5 text-primary" />
          </button>
          <h1 className="font-display text-lg font-bold text-foreground">Account Settings</h1>
        </header>
        <div className="px-5 py-6 space-y-5">
          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Email</label>
            <input
              readOnly
              value={user?.email || "No email"}
              className="w-full h-12 rounded-xl bg-card border border-border px-4 text-sm text-foreground outline-none opacity-80"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Phone</label>
            <input
              readOnly
              value={user?.phoneNumber || "Not provided"}
              className="w-full h-12 rounded-xl bg-card border border-border px-4 text-sm text-foreground outline-none opacity-80"
            />
          </div>
          <div className="pt-4 space-y-3">
            <button onClick={handleChangePassword} className="w-full h-12 rounded-2xl bg-card shadow-card text-sm font-bold text-primary hover:bg-secondary transition-colors">
              Send Password Reset Email
            </button>
            <button onClick={handleDeleteAccount} className="w-full h-12 rounded-2xl bg-destructive/10 text-sm font-bold text-destructive hover:bg-destructive/20 transition-colors">
              Delete Account
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Main settings
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg px-5 pt-5 pb-3 flex items-center gap-3">
        <button onClick={onBack} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
          <ArrowLeft className="h-5 w-5 text-primary" />
        </button>
        <h1 className="font-display text-lg font-bold text-foreground">Settings</h1>
      </header>
      <div className="px-5 py-4 space-y-1">
        {/* Dark mode */}
        <button onClick={toggleDark} className="flex items-center gap-3 w-full rounded-xl p-3.5 hover:bg-card transition-colors">
          {darkMode ? <Sun className="h-5 w-5 text-yellow-500" /> : <Moon className="h-5 w-5 text-muted-foreground" />}
          <span className="text-sm text-foreground flex-1 text-left">{darkMode ? "Light Mode" : "Dark Mode"}</span>
          <Toggle on={darkMode} onToggle={toggleDark} />
        </button>

        {[
          { icon: User, label: "Account Settings", key: "account" as SettingsSection },
          { icon: Shield, label: "Privacy & Safety", key: "privacy" as SettingsSection },
          { icon: Bell, label: "Notifications", key: "notifications" as SettingsSection },
        ].map((item) => (
          <button key={item.label} onClick={() => setSection(item.key)} className="flex items-center gap-3 w-full rounded-xl p-3.5 hover:bg-card transition-colors">
            <item.icon className="h-5 w-5 text-muted-foreground" />
            <span className="text-sm text-foreground flex-1 text-left">{item.label}</span>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </button>
        ))}

        <div className="pt-4 pb-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3.5">Legal</p>
        </div>
        {[
          { icon: FileText, label: "Privacy Policy", key: "policy" as SettingsSection },
          { icon: FileText, label: "Terms & Conditions", key: "terms" as SettingsSection },
          { icon: FileText, label: "Community Guidelines", key: "guidelines" as SettingsSection },
        ].map((item) => (
          <button key={item.label} onClick={() => setSection(item.key)} className="flex items-center gap-3 w-full rounded-xl p-3.5 hover:bg-card transition-colors">
            <item.icon className="h-5 w-5 text-muted-foreground" />
            <span className="text-sm text-foreground flex-1 text-left">{item.label}</span>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </button>
        ))}
        
        <div className="pt-6 pb-2">
          <button 
            onClick={() => auth.signOut()} 
            className="flex items-center justify-center gap-2 w-full rounded-xl p-3.5 bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors font-bold"
          >
            <LogOut className="h-5 w-5" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsScreen;

import { Heart, MessageCircle, X } from "lucide-react";
import { getAvatarStyle, type MockUser } from "@/data/mockData";
import { Button } from "@/components/ui/button";

interface MatchScreenProps {
  user: MockUser;
  onMessage: () => void;
  onClose: () => void;
}

const MatchScreen = ({ user, onMessage, onClose }: MatchScreenProps) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background/95 backdrop-blur-lg px-6">
      {/* Floating hearts */}
      {[...Array(8)].map((_, i) => (
        <Heart
          key={i}
          className="absolute text-accent/20 fill-accent/20 animate-float"
          style={{
            width: `${16 + Math.random() * 24}px`,
            height: `${16 + Math.random() * 24}px`,
            left: `${10 + Math.random() * 80}%`,
            top: `${10 + Math.random() * 80}%`,
            animationDelay: `${i * 0.4}s`,
            animationDuration: `${2 + Math.random() * 2}s`,
          }}
        />
      ))}

      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-6 right-6 flex h-10 w-10 items-center justify-center rounded-full bg-card shadow-card z-10"
      >
        <X className="h-5 w-5 text-muted-foreground" />
      </button>

      {/* Avatars */}
      <div className="relative flex items-center justify-center mb-8 animate-bounce-in">
        {/* Your avatar */}
        <div className="h-28 w-28 rounded-full gradient-royal p-[3px] shadow-elevated -mr-4 z-10">
          <div className="h-full w-full rounded-full" style={getAvatarStyle(20)} />
        </div>
        {/* Match avatar */}
        <div className="h-28 w-28 rounded-full gradient-warm p-[3px] shadow-elevated -ml-4">
          <div className="h-full w-full rounded-full" style={getAvatarStyle(user.img)} />
        </div>
        {/* Heart badge */}
        <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex h-12 w-12 items-center justify-center rounded-full gradient-warm shadow-elevated animate-pulse-heart">
          <Heart className="h-6 w-6 text-accent-foreground fill-accent-foreground" />
        </div>
      </div>

      {/* Text */}
      <div className="text-center animate-fade-up" style={{ animationDelay: "0.3s" }}>
        <h1 className="font-display text-4xl font-bold text-primary mb-2">
          It's a Match! <span className="text-accent">❤️</span>
        </h1>
        <p className="text-muted-foreground text-sm">
          You and <span className="font-semibold text-foreground">{user.name}</span> liked each other
        </p>
      </div>

      {/* Compatibility */}
      {user.compatibility && (
        <div className="mt-4 flex items-center gap-2 rounded-full gradient-warm px-4 py-2 shadow-card animate-fade-up" style={{ animationDelay: "0.5s" }}>
          <span className="text-sm font-bold text-accent-foreground">{user.compatibility}% Compatible</span>
        </div>
      )}

      {/* Shared interests */}
      <div className="flex flex-wrap justify-center gap-2 mt-4 animate-fade-up" style={{ animationDelay: "0.6s" }}>
        {user.interests.slice(0, 3).map((tag) => (
          <span key={tag} className="text-xs px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground font-medium">
            {tag}
          </span>
        ))}
      </div>

      {/* Actions */}
      <div className="flex flex-col gap-3 w-full max-w-xs mt-10 animate-fade-up" style={{ animationDelay: "0.7s" }}>
        <Button
          onClick={onMessage}
          className="w-full h-14 rounded-2xl gradient-royal text-accent-foreground text-lg font-semibold border-0 shadow-elevated hover:opacity-90 transition-opacity"
        >
          <MessageCircle className="mr-2 h-5 w-5" /> Send a Message
        </Button>
        <Button
          onClick={onClose}
          variant="ghost"
          className="w-full h-12 rounded-2xl text-muted-foreground text-sm font-medium"
        >
          Keep Exploring
        </Button>
      </div>
    </div>
  );
};

export default MatchScreen;

import { Heart, MapPin, MessageCircle, Repeat, Star, Bell } from "lucide-react";
import { getAvatarStyle } from "@/data/mockData";

interface Notification {
  id: number;
  type: "cross" | "like" | "match" | "message" | "recross";
  name: string;
  img: number;
  text: string;
  time: string;
  read: boolean;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  { id: 1, type: "recross", name: "Emma", img: 5, text: "You crossed paths again at Central Park 👀", time: "5 min ago", read: false },
  { id: 2, type: "match", name: "Aria", img: 4, text: "It's a match! Start chatting now ❤️", time: "15 min ago", read: false },
  { id: 3, type: "like", name: "Someone", img: 16, text: "Someone liked your profile", time: "1 hour ago", read: false },
  { id: 4, type: "cross", name: "Lina", img: 7, text: "You crossed paths near Union Square", time: "2 hours ago", read: true },
  { id: 5, type: "message", name: "Isabella", img: 15, text: "Sent you a new message", time: "3 hours ago", read: true },
  { id: 6, type: "cross", name: "Noah", img: 8, text: "You crossed paths near 5th Avenue", time: "4 hours ago", read: true },
  { id: 7, type: "recross", name: "Zara", img: 9, text: "You crossed paths with Zara for the 4th time! ✨", time: "5 hours ago", read: true },
  { id: 8, type: "like", name: "Someone", img: 17, text: "Someone sent you a Super Like ⭐", time: "6 hours ago", read: true },
];

const ICON_MAP = {
  cross: { icon: MapPin, gradient: "gradient-royal" },
  like: { icon: Heart, gradient: "gradient-warm" },
  match: { icon: Heart, gradient: "gradient-warm" },
  message: { icon: MessageCircle, gradient: "gradient-royal" },
  recross: { icon: Repeat, gradient: "gradient-gold" },
};

const NotificationsScreen = () => {
  const unread = MOCK_NOTIFICATIONS.filter((n) => !n.read);
  const read = MOCK_NOTIFICATIONS.filter((n) => n.read);

  return (
    <div className="px-5 pt-3 pb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-foreground">Notifications</h3>
        {unread.length > 0 && (
          <span className="text-xs font-medium text-accent">{unread.length} new</span>
        )}
      </div>

      {MOCK_NOTIFICATIONS.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Bell className="h-12 w-12 text-muted-foreground mb-3" />
          <p className="text-sm text-muted-foreground">No notifications yet</p>
          <p className="text-xs text-muted-foreground mt-1">Start exploring to get alerts!</p>
        </div>
      ) : (
        <div className="space-y-5">
          {/* New */}
          {unread.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-2 uppercase tracking-wider">New</p>
              <div className="space-y-1.5">
                {unread.map((notif, i) => {
                  const config = ICON_MAP[notif.type];
                  const Icon = config.icon;
                  return (
                    <div
                      key={notif.id}
                      className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-card animate-slide-in"
                      style={{ animationDelay: `${i * 0.06}s` }}
                    >
                      <div className="relative flex-shrink-0">
                        <div
                          className={`h-12 w-12 rounded-full ${notif.type === "like" ? "blur-sm" : ""}`}
                          style={getAvatarStyle(notif.img)}
                        />
                        <div className={`absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full ${config.gradient} shadow-card`}>
                          <Icon className="h-3 w-3 text-accent-foreground" />
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground">{notif.text}</p>
                        <p className="text-[11px] text-muted-foreground mt-0.5">{notif.time}</p>
                      </div>
                      <div className="h-2.5 w-2.5 rounded-full gradient-warm flex-shrink-0" />
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Earlier */}
          {read.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-2 uppercase tracking-wider">Earlier</p>
              <div className="space-y-1.5">
                {read.map((notif, i) => {
                  const config = ICON_MAP[notif.type];
                  const Icon = config.icon;
                  return (
                    <div
                      key={notif.id}
                      className="flex items-center gap-3 rounded-2xl p-3 opacity-70 animate-slide-in"
                      style={{ animationDelay: `${(unread.length + i) * 0.06}s` }}
                    >
                      <div className="relative flex-shrink-0">
                        <div
                          className={`h-12 w-12 rounded-full ${notif.type === "like" ? "blur-sm" : ""}`}
                          style={getAvatarStyle(notif.img)}
                        />
                        <div className={`absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-secondary shadow-card`}>
                          <Icon className="h-3 w-3 text-muted-foreground" />
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-foreground">{notif.text}</p>
                        <p className="text-[11px] text-muted-foreground mt-0.5">{notif.time}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationsScreen;

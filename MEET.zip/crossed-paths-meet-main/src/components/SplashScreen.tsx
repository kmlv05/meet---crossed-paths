import { Heart } from "lucide-react";

const SplashScreen = () => {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-4 animate-fade-up">
        <div className="relative">
          <Heart className="h-20 w-20 text-accent fill-accent animate-pulse-heart" />
          <div className="absolute inset-0 h-20 w-20 rounded-full gradient-warm opacity-20 blur-2xl" />
        </div>
        <h1 className="font-display text-5xl font-bold text-primary tracking-tight">
          Meet <span className="text-accent">❤️</span>
        </h1>
        <p className="text-muted-foreground text-lg">Find who crossed your path</p>
      </div>
    </div>
  );
};

export default SplashScreen;

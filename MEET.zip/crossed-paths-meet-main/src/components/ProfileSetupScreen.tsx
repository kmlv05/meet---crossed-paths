import { useState, useRef } from "react";
import { ArrowRight, ArrowLeft, Check, Camera, Plus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import { toast } from "sonner";

interface ProfileSetupScreenProps {
  onComplete: () => void;
}

const LOOKING_FOR = ["Dating", "Friendship", "Networking"];
const DRINKING = ["Never", "Socially", "Regularly"];
const SMOKING = ["Never", "Sometimes", "Regularly"];
const WORKOUT = ["Never", "Sometimes", "Often", "Daily"];
const EDUCATION = ["High School", "Bachelor's", "Master's", "PhD", "Other"];
const INTERESTS = [
  "Travel ✈️", "Music 🎵", "Tech 💻", "Fitness 💪", "Photography 📸",
  "Cooking 🍳", "Art 🎨", "Reading 📚", "Gaming 🎮", "Movies 🎬",
  "Coffee ☕", "Yoga 🧘", "Dancing 💃", "Sports ⚽", "Nature 🌿",
  "Fashion 👗", "Pets 🐾", "Anime 🎌", "Cars 🚗", "Startups 🚀",
];
const PROMPTS = [
  "My perfect weekend is…",
  "I'm looking for someone who…",
  "My most spontaneous moment…",
  "I geek out about…",
  "A life goal of mine is…",
];

const TOTAL_STEPS = 6;

interface PhotoData {
  url: string;
  file?: File;
}

const ProfileSetupScreen = ({ onComplete }: ProfileSetupScreenProps) => {
  const [step, setStep] = useState(0);
  const [lookingFor, setLookingFor] = useState("");
  const [drinking, setDrinking] = useState("");
  const [smoking, setSmoking] = useState("");
  const [workout, setWorkout] = useState("");
  const [education, setEducation] = useState("");
  const [job, setJob] = useState("");
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [promptAnswers, setPromptAnswers] = useState<Record<string, string>>({});
  const [photos, setPhotos] = useState<PhotoData[]>([]);
  const [bio, setBio] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);

  const toggleInterest = (i: string) => {
    setSelectedInterests((prev) =>
      prev.includes(i) ? prev.filter((x) => x !== i) : prev.length < 8 ? [...prev, i] : prev
    );
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      setPhotos([...photos, { url, file }]);
    }
  };

  const next = () => {
    if (step < TOTAL_STEPS - 1) {
      setStep(step + 1);
    } else {
      submitProfile();
    }
  };

  const back = () => step > 0 && setStep(step - 1);

  const progress = ((step + 1) / TOTAL_STEPS) * 100;

  const submitProfile = async () => {
    if (photos.length < 1) {
      toast.error("Please add at least 1 photo");
      return;
    }
    setLoading(true);
    const doSubmit = async (lat: number, lng: number) => {
      try {
        const imageUrls = [];
        for (const p of photos) {
          if (p.file) {
            const formData = new FormData();
            formData.append("file", p.file);
            const res = await api.post("/api/media/upload", formData, {
              headers: { "Content-Type": "multipart/form-data" }
            });
            imageUrls.push(res.data.imageUrl);
          }
        }

        await api.post("/api/users/profile", {
          bio,
          interests: selectedInterests,
          imageUrls,
          gender: "Not Specified",
          latitude: lat,
          longitude: lng,
        });

        toast.success("Profile fully configured!");
        onComplete();
      } catch (e: any) {
        console.error(e);
        toast.error(e.response?.data?.error || e.message || "Failed to submit profile");
      } finally {
        setLoading(false);
      }
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => doSubmit(pos.coords.latitude, pos.coords.longitude),
        (err) => {
          console.warn("Location error/denied.", err);
          doSubmit(40.7128, -74.0060); // Default gracefully to NY
        }
      );
    } else {
      doSubmit(40.7128, -74.0060);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 0:
        return (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-foreground">What are you looking for?</h2>
              <p className="text-sm text-muted-foreground mt-1">Choose what suits you best</p>
            </div>
            <div className="space-y-3">
              {LOOKING_FOR.map((opt) => (
                <button
                  key={opt}
                  onClick={() => setLookingFor(opt)}
                  className={`w-full text-left rounded-2xl px-5 py-4 text-sm font-medium transition-all ${
                    lookingFor === opt
                      ? "gradient-royal text-accent-foreground shadow-elevated"
                      : "bg-card shadow-card text-foreground"
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-5">
            <h2 className="font-display text-2xl font-bold text-foreground">About your lifestyle</h2>
            <div className="space-y-4">
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Drinking</p>
                <div className="flex flex-wrap gap-2">
                  {DRINKING.map((d) => (
                    <button key={d} onClick={() => setDrinking(d)}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${drinking === d ? "gradient-royal text-accent-foreground" : "bg-card shadow-card text-foreground"}`}
                    >{d}</button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Smoking</p>
                <div className="flex flex-wrap gap-2">
                  {SMOKING.map((s) => (
                    <button key={s} onClick={() => setSmoking(s)}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${smoking === s ? "gradient-royal text-accent-foreground" : "bg-card shadow-card text-foreground"}`}
                    >{s}</button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Workout</p>
                <div className="flex flex-wrap gap-2">
                  {WORKOUT.map((w) => (
                    <button key={w} onClick={() => setWorkout(w)}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${workout === w ? "gradient-royal text-accent-foreground" : "bg-card shadow-card text-foreground"}`}
                    >{w}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-5">
            <h2 className="font-display text-2xl font-bold text-foreground">Education & Career</h2>
            <div className="space-y-4">
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Education</p>
                <div className="flex flex-wrap gap-2">
                  {EDUCATION.map((e) => (
                    <button key={e} onClick={() => setEducation(e)}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${education === e ? "gradient-royal text-accent-foreground" : "bg-card shadow-card text-foreground"}`}
                    >{e}</button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Job / Profession</p>
                <input
                  value={job}
                  onChange={(e) => setJob(e.target.value)}
                  placeholder="e.g. Software Engineer"
                  className="w-full h-13 rounded-xl bg-card border border-border px-4 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-2xl font-bold text-foreground">Pick your interests</h2>
              <p className="text-sm text-muted-foreground mt-1">Choose up to 8 ({selectedInterests.length}/8)</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {INTERESTS.map((i) => (
                <button
                  key={i}
                  onClick={() => toggleInterest(i)}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                    selectedInterests.includes(i)
                      ? "gradient-warm text-accent-foreground shadow-card"
                      : "bg-card shadow-card text-foreground"
                  }`}
                >
                  {i}
                </button>
              ))}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-5">
            <h2 className="font-display text-2xl font-bold text-foreground">Personality prompts</h2>
            <div className="space-y-4">
              {PROMPTS.slice(0, 3).map((prompt) => (
                <div key={prompt}>
                  <p className="text-xs font-semibold text-muted-foreground mb-1.5">{prompt}</p>
                  <input
                    value={promptAnswers[prompt] || ""}
                    onChange={(e) => setPromptAnswers({ ...promptAnswers, [prompt]: e.target.value })}
                    placeholder="Type your answer…"
                    className="w-full h-12 rounded-xl bg-card border border-border px-4 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              ))}
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-5">
            <h2 className="font-display text-2xl font-bold text-foreground">Add your photos</h2>
            <p className="text-sm text-muted-foreground">Add at least 1 photo to continue</p>
            <input 
              type="file" 
              accept="image/*" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
            />
            <div className="grid grid-cols-3 gap-2.5">
              {[0, 1, 2, 3, 4, 5].map((idx) => {
                const photo = photos[idx];
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      if (!photo && fileInputRef.current) {
                        fileInputRef.current.click();
                      }
                    }}
                    className={`aspect-[3/4] rounded-2xl flex items-center justify-center transition-all overflow-hidden ${
                      photo
                        ? "shadow-elevated border-0"
                        : "bg-card shadow-card border-2 border-dashed border-border"
                    }`}
                  >
                    {photo ? (
                      <img src={photo.url} alt="Uploaded" className="w-full h-full object-cover" />
                    ) : idx === 0 ? (
                      <Camera className="h-6 w-6 text-muted-foreground" />
                    ) : (
                      <Plus className="h-5 w-5 text-muted-foreground" />
                    )}
                  </button>
                );
              })}
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Bio</p>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Write something about yourself…"
                rows={3}
                className="w-full rounded-xl bg-card border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-background px-6 py-8">
      <div className="flex items-center gap-3 mb-8">
        {step > 0 && (
          <button onClick={back} className="flex h-9 w-9 items-center justify-center rounded-full bg-card shadow-card">
            <ArrowLeft className="h-4 w-4 text-primary" />
          </button>
        )}
        <div className="flex-1 h-1.5 rounded-full bg-secondary overflow-hidden">
          <div
            className="h-full rounded-full gradient-royal transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="text-xs text-muted-foreground font-medium">{step + 1}/{TOTAL_STEPS}</span>
      </div>

      <div className="flex-1 animate-fade-up overflow-y-auto pb-24">
        {renderStep()}
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-lg px-6 py-4">
        <Button
          onClick={next}
          disabled={loading}
          className="w-full h-14 rounded-2xl gradient-royal text-accent-foreground text-lg font-semibold border-0 shadow-elevated hover:opacity-90 transition-opacity"
        >
          {loading ? (
             <span className="flex items-center gap-2"><Loader2 className="animate-spin w-5 h-5" /> Processing...</span>
          ) : step === TOTAL_STEPS - 1 ? (
             <>Start Exploring <ArrowRight className="ml-2 h-5 w-5" /></>
          ) : (
             <>Continue <ArrowRight className="ml-2 h-5 w-5" /></>
          )}
        </Button>
      </div>
    </div>
  );
};

export default ProfileSetupScreen;

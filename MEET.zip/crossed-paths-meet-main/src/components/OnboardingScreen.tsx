import { useState } from "react";
import { MapPin, Heart, MessageCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const slides = [
  {
    icon: MapPin,
    title: "Cross Paths",
    description: "Discover people you've crossed paths with in real life. Your next connection might be closer than you think.",
  },
  {
    icon: Heart,
    title: "Like & Match",
    description: "Like profiles that catch your eye. When someone likes you back, it's a match made in the real world.",
  },
  {
    icon: MessageCircle,
    title: "Start Talking",
    description: "Break the ice and start a conversation. Your story begins where your paths crossed.",
  },
];

interface OnboardingScreenProps {
  onComplete: () => void;
}

const OnboardingScreen = ({ onComplete }: OnboardingScreenProps) => {
  const [current, setCurrent] = useState(0);

  const handleNext = () => {
    if (current < slides.length - 1) {
      setCurrent(current + 1);
    } else {
      onComplete();
    }
  };

  const slide = slides[current];
  const Icon = slide.icon;

  return (
    <div className="flex min-h-screen flex-col items-center justify-between bg-background px-6 py-12">
      <button
        onClick={onComplete}
        className="self-end text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
      >
        Skip
      </button>

      <div className="flex flex-col items-center gap-8 text-center animate-fade-up" key={current}>
        <div className="flex h-32 w-32 items-center justify-center rounded-full bg-primary/10">
          <Icon className="h-16 w-16 text-primary" />
        </div>
        <div className="space-y-4">
          <h2 className="font-display text-4xl font-bold text-foreground">{slide.title}</h2>
          <p className="max-w-xs text-muted-foreground text-lg leading-relaxed">{slide.description}</p>
        </div>
      </div>

      <div className="flex w-full flex-col items-center gap-6">
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <div
              key={i}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === current ? "w-8 gradient-warm" : "w-2 bg-border"
              }`}
            />
          ))}
        </div>
        <Button
          onClick={handleNext}
          className="w-full max-w-xs h-14 rounded-2xl gradient-royal text-accent-foreground text-lg font-semibold border-0 shadow-elevated hover:opacity-90 transition-opacity"
        >
          {current < slides.length - 1 ? "Next" : "Get Started"}
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  );
};

export default OnboardingScreen;

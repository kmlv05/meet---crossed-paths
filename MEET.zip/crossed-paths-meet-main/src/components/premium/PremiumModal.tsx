import { useState } from "react";
import { X, Crown, Sparkles, Eye, Zap, Star, Calendar, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import { toast } from "sonner";

interface PremiumModalProps {
  onClose: () => void;
}

const FEATURES = [
  { icon: Eye, title: "See Who Likes You", desc: "Unlock your secret admirers" },
  { icon: Star, title: "Unlimited Likes", desc: "Like as many people as you want" },
  { icon: Zap, title: "Profile Boost", desc: "Get 10x more visibility" },
  { icon: Sparkles, title: "AI Match Suggestions", desc: "Smart compatibility scoring" },
  { icon: Calendar, title: "Exclusive Club Events", desc: "Access VIP events & parties" },
  { icon: Shield, title: "Advanced Filters", desc: "Filter by interests, distance & more" },
];

const PremiumModal = ({ onClose }: PremiumModalProps) => {
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (planType: string) => {
    try {
      setLoading(true);
      const origin = window.location.origin;
      const res = await api.post('/api/payment/create-checkout-session', { planType, origin });
      if (res.data.url) {
        window.location.href = res.data.url;
      }
    } catch (err) {
      console.error("Payment error", err);
      toast.error("Failed to start checkout process");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm animate-fade-up" onClick={onClose}>
      <div className="w-full max-w-lg bg-background rounded-t-3xl px-5 pt-6 pb-8 max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <Crown className="h-6 w-6 text-yellow-500" />
            <h2 className="font-display text-xl font-bold text-foreground">Meet Premium</h2>
          </div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-full bg-card shadow-card">
            <X className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>

        <div className="space-y-2.5 mb-6">
          {FEATURES.map((feature, i) => (
            <div
              key={feature.title}
              className="flex items-center gap-3 rounded-xl bg-card shadow-card p-3 animate-slide-in"
              style={{ animationDelay: `${i * 0.06}s` }}
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-full gradient-gold flex-shrink-0">
                <feature.icon className="h-4 w-4 text-accent-foreground" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">{feature.title}</p>
                <p className="text-[11px] text-muted-foreground">{feature.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <div className="grid grid-cols-2 gap-4 mb-5">
          <div 
            className={`rounded-2xl gradient-royal p-4 text-center shadow-elevated cursor-pointer transition-opacity ${loading ? 'opacity-50' : 'hover:opacity-90'}`}
            onClick={() => !loading && handleSubscribe('weekly')}
          >
            <p className="text-accent-foreground/70 text-xs mb-1">Weekly</p>
            <div className="flex items-baseline justify-center gap-1">
              <span className="text-3xl font-bold text-accent-foreground">₹50</span>
              <span className="text-accent-foreground/60 text-xs">/wk</span>
            </div>
            <p className="text-accent-foreground/50 text-[10px] mt-1">Cancel anytime</p>
          </div>
          
          <div 
            className={`rounded-2xl gradient-gold p-4 text-center shadow-elevated cursor-pointer transition-opacity ${loading ? 'opacity-50' : 'hover:opacity-90'}`}
            onClick={() => !loading && handleSubscribe('monthly')}
          >
             <p className="text-accent-foreground/70 text-xs text-black mb-1">Monthly</p>
            <div className="flex items-baseline justify-center gap-1">
              <span className="text-3xl font-bold text-black">₹199</span>
              <span className="text-accent-foreground/60 text-xs text-black">/mo</span>
            </div>
            <p className="text-accent-foreground/50 text-[10px] text-black mt-1">Best value</p>
          </div>
        </div>

        <p className="text-center text-[10px] text-muted-foreground mt-3">
          Recurring billing. Terms apply.
        </p>
      </div>
    </div>
  );
};

export default PremiumModal;

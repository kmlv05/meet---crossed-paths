import heroPeople from "@/assets/hero-people.jpg";

export interface MockUser {
  id: number;
  name: string;
  age: number;
  distance?: string;
  time?: string;
  location?: string;
  crossCount?: number;
  img: number;
  realImageUrls?: string[];
  bio: string;
  interests: string[];
  personalityTags: string[];
  job?: string;
  music?: string;
  compatibility?: number;
  online?: boolean;
  lastMessage?: {
    text: string;
    time: string;
    unread: number;
    isMine?: boolean;
    status?: "sent" | "delivered" | "read";
  };
}

export const MOCK_NEARBY: MockUser[] = [
  { id: 1, name: "Sofia", age: 26, distance: "200m", img: 0, bio: "Art lover & coffee enthusiast ☕", interests: ["Art", "Coffee", "Yoga"], personalityTags: ["Creative", "Calm"], job: "Graphic Designer", music: "Lo-fi Beats", compatibility: 92, online: true },
  { id: 2, name: "Alex", age: 28, distance: "350m", img: 1, bio: "Musician by night, coder by day 🎸", interests: ["Music", "Tech", "Travel"], personalityTags: ["Adventurous", "Witty"], job: "Software Engineer", music: "Indie Rock", compatibility: 87, online: false },
  { id: 3, name: "Maya", age: 24, distance: "500m", img: 2, bio: "Wanderlust & good vibes ✨", interests: ["Travel", "Photography", "Food"], personalityTags: ["Free Spirit", "Empathetic"], job: "Photographer", music: "Bossa Nova", compatibility: 78, online: true },
  { id: 4, name: "Lucas", age: 27, distance: "800m", img: 3, bio: "Fitness freak & dog dad 🐕", interests: ["Fitness", "Dogs", "Cooking"], personalityTags: ["Energetic", "Loyal"], job: "Personal Trainer", music: "EDM", compatibility: 65, online: false },
  { id: 5, name: "Aria", age: 25, distance: "1.2km", img: 4, bio: "Bookworm with a taste for adventure 📚", interests: ["Reading", "Hiking", "Wine"], personalityTags: ["Thoughtful", "Curious"], job: "Writer", music: "Jazz", compatibility: 95, online: true },
  { id: 6, name: "Ethan", age: 29, distance: "1.5km", img: 10, bio: "Architect of dreams 🏛️", interests: ["Architecture", "Design", "Running"], personalityTags: ["Visionary", "Focused"], job: "Architect", music: "Classical", compatibility: 71, online: false },
];

export const MOCK_CROSSED: MockUser[] = [
  { id: 7, name: "Emma", age: 25, time: "10 min ago", location: "Central Park", crossCount: 3, img: 5, bio: "Morning runner, sunset chaser 🌅", interests: ["Running", "Nature", "Meditation"], personalityTags: ["Active", "Peaceful"], compatibility: 88, online: true },
  { id: 8, name: "James", age: 29, time: "25 min ago", location: "Broadway Café", crossCount: 1, img: 6, bio: "Chef in training 👨‍🍳", interests: ["Cooking", "Wine", "Jazz"], personalityTags: ["Passionate", "Social"], compatibility: 74, online: false },
  { id: 9, name: "Lina", age: 23, time: "1 hour ago", location: "Union Square", crossCount: 5, img: 7, bio: "Dancing through life 💃", interests: ["Dance", "Fashion", "Art"], personalityTags: ["Expressive", "Bold"], compatibility: 91, online: true },
  { id: 10, name: "Noah", age: 30, time: "2 hours ago", location: "5th Avenue", crossCount: 2, img: 8, bio: "Startup founder & pizza lover 🍕", interests: ["Tech", "Startups", "Food"], personalityTags: ["Driven", "Humorous"], compatibility: 82, online: false },
  { id: 11, name: "Zara", age: 26, time: "3 hours ago", location: "SoHo Gallery", crossCount: 4, img: 9, bio: "Art curator & wine connoisseur 🎨", interests: ["Art", "Wine", "Film"], personalityTags: ["Sophisticated", "Creative"], compatibility: 96, online: true },
];

export const MOCK_MATCHES: MockUser[] = [
  { id: 12, name: "Isabella", age: 24, img: 15, bio: "Piano player & stargazer 🌟", interests: ["Music", "Astronomy", "Poetry"], personalityTags: ["Romantic", "Dreamy"], compatibility: 94, online: true },
  { id: 13, name: "Oliver", age: 27, img: 11, bio: "Globe trotter seeking adventure 🌍", interests: ["Travel", "Surfing", "Photography"], personalityTags: ["Adventurous", "Open"], compatibility: 89, online: false },
  { id: 14, name: "Mia", age: 25, img: 12, bio: "Yoga instructor & plant mom 🌿", interests: ["Yoga", "Plants", "Wellness"], personalityTags: ["Zen", "Nurturing"], compatibility: 87, online: true },
];

export const getAvatarStyle = (index: number): React.CSSProperties => {
  const col = index % 5;
  const row = Math.floor(index / 5);
  return {
    backgroundImage: `url(${heroPeople})`,
    backgroundSize: "500%",
    backgroundPosition: `${col * 25}% ${row * 25}%`,
  };
};

export const ICEBREAKERS = [
  "What's the most spontaneous thing you've ever done? 🎲",
  "If we met at a coffee shop, what would you order? ☕",
  "Describe your perfect Sunday in 3 words 🌞",
  "What song is stuck in your head right now? 🎵",
  "Beach vacation or mountain getaway? ⛰️",
];

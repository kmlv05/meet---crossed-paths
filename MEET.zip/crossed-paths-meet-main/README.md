# Meet Full-Stack App

This is a complete full-stack implementation of the "Meet" dating/social app, featuring a Java Spring Boot backend and a React/Vite frontend. It uses Firebase for Authentication, Database (Firestore), and Storage.

## Overview
- **Backend Details:** Located in `backend/` utilizing Spring Boot 3.4.0 and Firebase Admin SDK. Exposes REST APIs `/api/users`, `/api/match`, `/api/chat`, and `/api/media`. Protected by a custom `JwtTokenFilter` utilizing stateless Firebase ID token verification. 
- **Frontend Details:** Vite + React + TailwindCSS application securely bridging interactions using an `Axios` interceptor holding short-lived JWTs. The responsive layout defaults to a full screen on Mobile but bounds the elements nicely into an "app emulator" frame on Desktop for an immaculate UX.

Please check the Antigravity `walkthrough.md` for a deeper guide on provisioning the configuration fields required to run this app locally.
